package com.sin;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import dos.conexion.*;
import dos.anotaciones.MiComponente;
import java.sql.Connection; // Importante añadir esta

@MiComponente(name = "servicioProductos", singleton = true)
public class Singleton {
    private static Singleton instancia = null;
    private static DbConfig dbConfig; // Solo la declaración
    private static final Lock lock = new ReentrantLock();

    private Singleton() {
        try {
            // 1. PRIMERO: Crea el objeto DbConfig
            dbConfig = new DbConfig(); 
            
            // 2. SEGUNDO: Obtén la conexión (esto devuelve un objeto Connection)
            Connection conn = dbConfig.getConnection(); 
            
            if (conn != null) {
                System.out.println("CONEXION EXITOSA!");
                // Opcional: podrías cerrar la conexión de prueba o guardarla
                conn.close(); 
            }
        } catch(Exception e) {
            System.err.println("Error al inicializar la base de datos:");
            e.printStackTrace();
        }
    }
    
    // El método getInstance() que tienes está perfecto (Double-Checked Locking)
    public static Singleton getInstance() {
        if(instancia == null) {
            lock.lock();
            try {
                if(instancia == null) {
                    instancia = new Singleton();
                }
            } finally {
                lock.unlock();
            }
        } else {
            System.out.println("Se devuelve la instancia existente");
        }
        return instancia;
    }
}