package com;
import java.util.List;

import com.sin.*;

import dos.conexion.DbConfig;
import dos.servicios.*;
public class AppSingleton {

	public static void main(String[] args) {
	
		// inicializar el Singleton (y por ende Hikari)
        Singleton.getInstance();
        
        // configurar el Servicio (Usamos una instancia de DbConfig)
        DbConfig db = new DbConfig(); 
        ServicioProducto servicio = new ServicioProdImpl(); //CRUD
        servicio.setDBConfig(db);
        System.out.println(".....");

        
        //CRUD

        //CREATE: crear producto
//        System.out.println("\n--- Creando Producto ---");
//        Productos nuevo = new Productos("Hot Wheels 83 Chevy", 2.50);
//        servicio.createProd(nuevo);

        System.out.println(".....");
        
        //READ: Listar todos
//        System.out.println("Productos");
//        List<Productos> lista = servicio.listaProd();
//        System.out.println(lista);
        
        System.out.println(".....");

        
        //UPDATE: actualizar por nombre
//        String nombreAnterior = "Hot Wheels 83 Chevy";
//        Productos nuevosDatos = new Productos("Subaru Impreza WRX", 2.99);
//        servicio.actualizar(nombreAnterior, nuevosDatos);
        
        System.out.println(".....");
        
        // DELETE: eliminar por id
        //servicio.eliminar(1);
        


		
		
	}

}
