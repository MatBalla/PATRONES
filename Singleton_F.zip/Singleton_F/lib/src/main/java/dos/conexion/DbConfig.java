package dos.conexion;


import java.sql.Connection;
import java.sql.SQLException;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class DbConfig {

	private HikariConfig config = new HikariConfig();
	private HikariDataSource dataSource;

	{
		config.setJdbcUrl("jdbc:sqlite:PatronesDB.db"); //BD nueva para clase
//		config.setJdbcUrl("jdbc:sqlite:PatronesDB.db"); //BD de practica
		config.setUsername("sa");
		config.setPassword("");
		config.setConnectionTimeout(1000);
		dataSource = new HikariDataSource(config);

	}

	public Connection getConnection() {

		try {
			System.out.println("Conectando");
			return dataSource.getConnection();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}

}
