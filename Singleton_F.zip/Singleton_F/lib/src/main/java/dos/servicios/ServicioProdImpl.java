package dos.servicios;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import dos.conexion.DbConfig;

public class ServicioProdImpl implements ServicioProducto {

    private DbConfig dbconfig;

    @Override
    public void setDBConfig(DbConfig dbconfig) {
        this.dbconfig = dbconfig;
    }

    @Override
    public void createProd(Productos p) {
        String sql = "INSERT INTO producto (nombre, precio) VALUES (?, ?)";
        try (Connection conn = dbconfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, p.getNombre());
            pstmt.setDouble(2, p.getPrecio());
            pstmt.executeUpdate();
            System.out.println("✅ Producto creado: " + p.getNombre());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Productos> listaProd() {
        List<Productos> lista = new ArrayList<>();
        String sql = "SELECT * FROM producto";
        try (Connection conn = dbconfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Productos(rs.getString("nombre"), rs.getDouble("precio")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    @Override
    public Productos buscarproducto(int id) {
        String sql = "SELECT * FROM producto WHERE id = ?";
        try (Connection conn = dbconfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Productos(rs.getString("nombre"), rs.getDouble("precio"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    // UPDATE: Buscar por nombre y actualizar datos
    public void actualizar(String nombreBuscar, Productos p) {
        //actualiza el nombre y el precio filtrando por el nombre anterior
        String sql = "UPDATE producto SET nombre = ?, precio = ? WHERE nombre = ?";
        
        try (Connection conn = dbconfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, p.getNombre()); // nuevo nombre
            pstmt.setDouble(2, p.getPrecio()); // nuevo precio
            pstmt.setString(3, nombreBuscar);   // nombre que ya existe en la BD
            
            pstmt.executeUpdate();
            System.out.println("Registro actualizado correctamente.");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) { //elimina por id
        String sql = "DELETE FROM producto WHERE id = ?";
        try (Connection conn = dbconfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            System.out.println("🗑️ Producto eliminado ID: " + id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}