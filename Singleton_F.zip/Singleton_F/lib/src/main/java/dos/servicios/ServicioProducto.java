package dos.servicios;

import java.util.List;

import dos.conexion.*;

public interface ServicioProducto {
	void setDBConfig(DbConfig dbconfig);
	Productos buscarproducto(int id);
	List<Productos> listaProd();
	void actualizar (String nombreBuscar, Productos p);
	void eliminar(int id);
	void createProd(Productos p);
	
}

