package dos.servicios;

import java.util.List;

import dos.conexion.DbConfig;

public class ServicioProdImpl implements ServicioProducto{

	@Override
	public void setDBConfig(DbConfig dbconfig) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Productos buscarproducto(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Productos> listaProd() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void actualizar(Productos p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void eliminar(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createProd(Productos p) {
		// TODO Auto-generated method stub
		
	}

}
