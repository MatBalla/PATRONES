package com.model;

import java.util.ArrayList;
import java.util.List;

public class CareTaker {
	private List<Memento> estados = new ArrayList<Memento>();
	private Memento m;
	
	public void almacenarMemento(Memento m) {
		this.m = m;
	}
	
	public Memento recuperarMemento() {
		return m;
	}
	
	public void addMemento(Memento m) {
		estados.add(m);
	}
	
	public Memento getMemento(int index) {
		return estados.get(index);
	}

}
