package com.model;

public class Originator {
	private String estado;
	private Memento m;

	public void setEstado(String estado) {
		this.estado = estado;
		System.out.println("Estado actual: " + estado);
	}

	public Memento salvarMemento() {
		this.m = new Memento(estado);
		return m;
	}

	public void revertir(Memento m) {
		System.out.println("Restaurando al estado anterior");
		this.estado = m.getSalvaEstado();
		System.out.println("Estado modificado a: " + estado);

	}
	public String getEstado() {
		return this.estado;
	}

}
