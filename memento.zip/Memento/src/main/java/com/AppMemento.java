package com;

import com.model.CareTaker;
import com.model.Memento;
import com.model.Originator;

public class AppMemento {

	public static void main(String[] args) {
		Originator o = new Originator();
		o.setEstado("primer estado");
		CareTaker c = new CareTaker();
		c.almacenarMemento(o.salvarMemento());
		o.setEstado("segundo estado");
		o.revertir(c.recuperarMemento());
		o.setEstado("Nuevo estado");
		c.addMemento(o.salvarMemento());
		o.setEstado("tercer estado");
		c.addMemento(o.salvarMemento());
		o.setEstado("ultimo estado");

		Memento m1 = c.getMemento(0);
		Memento m2 = c.getMemento(1);
		//Memento m3 = c.getMemento(2);

		o.revertir(c.getMemento(0));

	}

}
