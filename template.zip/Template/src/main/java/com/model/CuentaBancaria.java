package com.model;

public abstract class CuentaBancaria {
	private String cuenta;
	private int saldo;

	private void setCuenta(String cta) {
		this.cuenta = cta;
	}

	private void depositar(int val) {
		System.out.println("Depositando....");
		this.saldo += val;
	}

	public void retirar(int val) {
		System.out.println("Retirando....");
		if (val <= this.saldo - 10) {
			this.saldo -= val;
		} else {
			System.out.println("Saldo insuficiente para la realizar la transaccion");
		}
	}

	private void consultarSaldo() {
		System.out.println("El saldo actual es: " + this.saldo);
	}
	
	protected void auditoria() {
		System.out.println("Se ha procesado la transaccion verificando la identidad de la cueta: " + this.cuenta);
	}

	public abstract void confirmar();
	public void procesar(String cta, int val, int tipo) {
		confirmar();
		setCuenta(cta);
		switch (tipo) {
		case 1:
			depositar(val);
			break;
		case 2:
			retirar(val);
		default:
			System.out.println("Opcion no valida");
		}
		consultarSaldo();
		auditoria();
		
	}

}
