package com.model;

public class Cajero extends CuentaBancaria{
	
	public Cajero(String cta, int valor, int tipo) {
		procesar(cta,valor,tipo);
	}

	@Override
	public void confirmar() {
		System.out.println("se ha vericado identidad con su cedula, que transaccion desea realizar: ");
	}
	
	@Override
	public void auditoria() {
		super.auditoria();
		System.out.println("Fue un placer atenderlo..");
	}

}
