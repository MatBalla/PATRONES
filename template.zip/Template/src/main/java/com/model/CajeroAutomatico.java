package com.model;

public class CajeroAutomatico extends CuentaBancaria {

	public CajeroAutomatico(String cta, int valor, int tipo) {
		procesar(cta, valor, tipo);
	}

	@Override
	public void confirmar() {
		System.out.println("Espera esta verificando datos");
	}
	

}