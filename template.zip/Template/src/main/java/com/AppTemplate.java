package com;

import java.util.Scanner;

import com.model.Cajero;
import com.model.CajeroAutomatico;

public class AppTemplate {

	public static void main(String[] args) {
		CajeroAutomatico ca = new CajeroAutomatico("cta 1234", 30, menu());
		ca.procesar("cta 1234", 25, menu());
		Cajero c = new Cajero("cta987", 10, menu());
		c.procesar("cta987", 15, menu());
		
	}
	
	public static int menu() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Escoja una opcion: 1. Depositar 2.Retirar ");
		return sc.nextInt();
	}

}
