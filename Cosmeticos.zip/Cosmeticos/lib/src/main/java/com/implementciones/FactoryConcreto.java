package com.implementciones;

import com.clases.CosmeticoAmericano;
import com.enumeracion.TipoAsiatico;
import com.enumeracion.TipoProducto;
import com.factory.IFactory;
import com.interfaces.ICosmeticos;
import com.subclaseAsiatico.CosmeticaDecorativa;
import com.subclaseAsiatico.RutinaFacial;
import com.subclasesEuropeos.Permanentes;
import com.subclasesEuropeos.Semipermanentes;

public class FactoryConcreto implements IFactory {

    @Override
    public ICosmeticos crearFactory(TipoProducto tipo) {
        switch (tipo) {
            case COSMETICO_AMERICANO:
                return new CosmeticoAmericano("A1", "Victoria Secret", 34, "02-06-2024", "02-06-2026", 4, "EEUU", "FDA-2024-001", "Evotar contaco con ojos");

            case COSMETICO_EUROPEO_PERMANENTE:
                return new Permanentes("EU1", "Chanel", 89, "01-01-2024", "01-01-2027", 12, "Francia", "EGEGR", "Retinol", "24 meses", 2);

            case COSMETICO_EUROPEO_SEMIPERMANENTE:
                return new Semipermanentes("EU2", "Dior", 55, "01-03-2024", "01-03-2025", 8, "Francia", "KJNGDG", "6 meses");

            case COSMETICO_ASIATICO_FACIAL:
                return new RutinaFacial("AS1", "Serum", 40, "15-02-2024", "15-02-2026", 5, "Corea", "Piel mixta", TipoAsiatico.RUTINA_FACIAL);

            case COSMETICO_ASIATICO_DECORATIVA:
                return new CosmeticaDecorativa("AS2", "Algocosmetico", 30, "10-01-2024", "10-01-2026", 3, "Japon", "Piel seca", TipoAsiatico.COSMETICA_DECORATIVA);

            default:
                throw new IllegalArgumentException("No se reconoce " + tipo);
        }
    }
}
