package com.subclaseAsiatico;

import com.clases.CosmeticosAsiaticos;
import com.enumeracion.TipoAsiatico;

public class RutinaFacial extends CosmeticosAsiaticos {

    public RutinaFacial(String codigo, String nombre, int precio_base, String fecha_fabricacion,
            String fecha_caducidad, int numero_lote, String pais_origen, String tipo_piel, TipoAsiatico tipo) {
        super(codigo, nombre, precio_base, fecha_fabricacion, fecha_caducidad, numero_lote, pais_origen, tipo_piel, tipo);
    }

    @Override
    public void informacion() {
        System.out.println(toString());
    }
}
