package com.state;

public class CosmeticoContext{

	private EstadoCosmetico estado;
	private String nombre;

	public CosmeticoContext(String nombre){
		this.nombre = nombre;
		this.estado = new Produccion();
		System.out.println(nombre + " creado en estado  " + estado.getNombre());
	}

	public void setEstado(EstadoCosmetico estado){
		this.estado = estado;
		System.out.println(nombre + ", " + estado.getNombre());
	}

	public void avanzar(){ 
		estado.avanzar(this); 
	}


	public void vender(){ 
		estado.vender(this);  
	}

	public String getEstado(){ 
		return estado.getNombre(); 
	}
}
