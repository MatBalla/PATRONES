package com.state;

public interface EstadoCosmetico {
    void avanzar(CosmeticoContext algo);
    void vender(CosmeticoContext algo);
    String getNombre();
}
