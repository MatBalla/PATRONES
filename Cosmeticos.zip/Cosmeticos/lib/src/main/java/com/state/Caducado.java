package com.state;

public class Caducado implements EstadoCosmetico {

    @Override
    public void avanzar(CosmeticoContext algo) {
        System.out.println("El producto esta caducado");
    }

    @Override
    public void vender(CosmeticoContext algo) {
        System.out.println("El producto esta caducado");
    }

    @Override
    public String getNombre() { 
    	return "Caducado"; 
    }
}
