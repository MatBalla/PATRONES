package com.state;

public class DisponibleVenta implements EstadoCosmetico {

    @Override
    public void avanzar(CosmeticoContext algo){
        algo.setEstado(new Caducado());
    }

    @Override
    public void vender(CosmeticoContext algo){
        System.out.println("  Vendido correctamente" + algo.getEstado());
    }

    @Override
    public String getNombre(){ 
    	return "Disponible"; 
    }
}
