package com.state;

public class controlCalidad implements EstadoCosmetico {

    @Override
    public void avanzar(CosmeticoContext algo){
        algo.setEstado(new DisponibleVenta());
    }

    @Override
    public void vender(CosmeticoContext algo){
        System.out.println("  No se puede vender: esta en control de calidad");
    }

    @Override
    public String getNombre() { 
    	return "En control de calidad"; 
    }
}
