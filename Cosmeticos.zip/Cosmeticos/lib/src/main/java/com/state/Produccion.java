package com.state;

public class Produccion implements EstadoCosmetico {

    @Override
    public void avanzar(CosmeticoContext algo){
        algo.setEstado(new controlCalidad());
    }

    @Override
    public void vender(CosmeticoContext algo){
        System.out.println("  No se puede vender: esta en produccion");
    }

    @Override
    public String getNombre(){ 
    	return "En produccion"; 
    }
}
