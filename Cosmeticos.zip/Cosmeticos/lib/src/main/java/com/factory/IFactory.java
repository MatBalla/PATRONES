package com.factory;

import com.enumeracion.TipoProducto;
import com.interfaces.ICosmeticos;

public interface IFactory {
    ICosmeticos crearFactory(TipoProducto tipo);
}
