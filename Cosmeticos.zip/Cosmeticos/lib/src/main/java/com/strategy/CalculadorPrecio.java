package com.strategy;

import com.clases.Cosmetico;

public class CalculadorPrecio {

    private PrecioStrategy estrategia;

    public CalculadorPrecio(PrecioStrategy estrategia) {
        this.estrategia = estrategia;
    }

    public void setEstrategia(PrecioStrategy estrategia) {
        this.estrategia = estrategia;
    }

    public void mostrarPrecio(Cosmetico cosmetico) {
        double precio = estrategia.calcularPrecio(cosmetico.getPrecio_base());
        System.out.println("  Precio de " + cosmetico.getNombre() + ", con precio de " + precio);
    }
}
