package com.strategy;

public interface PrecioStrategy {
    double calcularPrecio(int precioBase);
}
