package com.strategy;

public class MercadoLocal implements PrecioStrategy {

    @Override
    public double calcularPrecio(int precioBase) {
        return precioBase * 1.12;
    }
}
