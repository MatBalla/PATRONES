package com.strategy;

public class MercadoMayorista implements PrecioStrategy {

    @Override
    public double calcularPrecio(int precioBase) {
        return precioBase * 0.85;
    }
}
