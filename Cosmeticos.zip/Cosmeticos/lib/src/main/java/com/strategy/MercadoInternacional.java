package com.strategy;

public class MercadoInternacional implements PrecioStrategy {

    @Override
    public double calcularPrecio(int precioBase) {
        return precioBase * 1.35;
    }
}
