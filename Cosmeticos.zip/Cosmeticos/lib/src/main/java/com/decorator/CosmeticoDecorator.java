package com.decorator;

import com.interfaces.ICosmeticos;

public abstract class CosmeticoDecorator implements ICosmeticos {

    protected ICosmeticos cosmetico;

    public CosmeticoDecorator(ICosmeticos cosmetico) {
        this.cosmetico = cosmetico;
    }

    @Override
    public void informacion() {
        cosmetico.informacion();
    }
}
