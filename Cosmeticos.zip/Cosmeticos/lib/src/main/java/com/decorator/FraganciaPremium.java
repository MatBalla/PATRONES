package com.decorator;

import com.interfaces.ICosmeticos;

public class FraganciaPremium extends CosmeticoDecorator {

    public FraganciaPremium(ICosmeticos cosmetico) {
        super(cosmetico);
    }

    @Override
    public void informacion() {
        cosmetico.informacion();
        System.out.println("  + Fragancia premium");
    }
}
