package com.decorator;

import com.interfaces.ICosmeticos;

public class CertificacionVegana extends CosmeticoDecorator {

    public CertificacionVegana(ICosmeticos cosmetico) {
        super(cosmetico);
    }

    @Override
    public void informacion() {
        cosmetico.informacion();
        System.out.println("  + Certificacion vegana");
    }
}
