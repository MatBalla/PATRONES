package com.decorator;

import com.interfaces.ICosmeticos;

public class ProteccionUV extends CosmeticoDecorator {

    public ProteccionUV(ICosmeticos cosmetico) {
        super(cosmetico);
    }

    @Override
    public void informacion() {
        cosmetico.informacion();
        System.out.println("  + Proteccion UV");
    }
}
