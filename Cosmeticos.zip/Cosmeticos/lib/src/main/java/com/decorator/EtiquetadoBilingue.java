package com.decorator;

import com.interfaces.ICosmeticos;

public class EtiquetadoBilingue extends CosmeticoDecorator {

    public EtiquetadoBilingue(ICosmeticos cosmetico) {
        super(cosmetico);
    }

    @Override
    public void informacion() {
        cosmetico.informacion();
        System.out.println("  + Etiquetado bilingue");
    }
}
