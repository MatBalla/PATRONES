package com.decorator;

import com.interfaces.ICosmeticos;

public class EmpaqueEcologico extends CosmeticoDecorator {

    public EmpaqueEcologico(ICosmeticos cosmetico) {
        super(cosmetico);
    }

    @Override
    public void informacion() {
        cosmetico.informacion();
        System.out.println("  + Empaque ecologico");
    }
}
