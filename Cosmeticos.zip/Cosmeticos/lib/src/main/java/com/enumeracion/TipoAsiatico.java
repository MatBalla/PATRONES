package com.enumeracion;

public enum TipoAsiatico {
    RUTINA_FACIAL, COSMETICA_DECORATIVA
}
