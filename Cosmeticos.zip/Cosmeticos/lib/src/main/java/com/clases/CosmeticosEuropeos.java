package com.clases;

public abstract class CosmeticosEuropeos extends Cosmetico {

    private String norma;

    public CosmeticosEuropeos(String codigo, String nombre, int precio_base, String fecha_fabricacion,
            String fecha_caducidad, int numero_lote, String pais_origen, String norma) {
        super(codigo, nombre, precio_base, fecha_fabricacion, fecha_caducidad, numero_lote, pais_origen);
        this.norma = norma;
    }

    public String getNorma() { return norma; }

    @Override
    public String toString() {
        return "ProductosEuropeos [norma=" + norma + "]";
    }
}
