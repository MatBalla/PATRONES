package com.clases;

import com.interfaces.ICosmeticos;

public abstract class Cosmetico implements ICosmeticos {

    private String codigo;
    private String nombre;
    private int precio_base;
    private String fecha_fabricacion;
    private String fecha_caducidad;
    private int numero_lote;
    private String pais_origen;

    public Cosmetico(String codigo, String nombre, int precio_base, String fecha_fabricacion,
            String fecha_caducidad, int numero_lote, String pais_origen) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio_base = precio_base;
        this.fecha_fabricacion = fecha_fabricacion;
        this.fecha_caducidad = fecha_caducidad;
        this.numero_lote = numero_lote;
        this.pais_origen = pais_origen;
    }

    public String getCodigo()             { return codigo; }
    public String getNombre()             { return nombre; }
    public int getPrecio_base()           { return precio_base; }
    public String getFecha_fabricacion()  { return fecha_fabricacion; }
    public String getFecha_caducidad()    { return fecha_caducidad; }
    public int getNumero_lote()           { return numero_lote; }
    public String getPais_origen()        { return pais_origen; }

    @Override
    public String toString() {
        return "Cosmetico [codigo=" + codigo + ", nombre=" + nombre + ", precio_base=" + precio_base
                + ", fecha_fabricacion=" + fecha_fabricacion + ", fecha_caducidad=" + fecha_caducidad
                + ", numero_lote=" + numero_lote + ", pais_origen=" + pais_origen + "]";
    }
}
