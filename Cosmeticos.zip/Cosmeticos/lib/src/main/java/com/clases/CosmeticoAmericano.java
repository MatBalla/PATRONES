package com.clases;

public class CosmeticoAmericano extends CosmeticosAmericanos {

    public CosmeticoAmericano(String codigo, String nombre, int precio_base, String fecha_fabricacion,
            String fecha_caducidad, int numero_lote, String pais_origen,
            String codigoOrganismo, String advertencias) {
        super(codigo, nombre, precio_base, fecha_fabricacion, fecha_caducidad, numero_lote, pais_origen,
                codigoOrganismo, advertencias);
    }

    @Override
    public void informacion() {
        System.out.println(toString());
    }
}
