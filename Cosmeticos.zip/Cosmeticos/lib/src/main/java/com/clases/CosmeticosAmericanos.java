package com.clases;

public abstract class CosmeticosAmericanos extends Cosmetico {

    private String codigoOrganismo;
    private String advertencias;

    public CosmeticosAmericanos(String codigo, String nombre, int precio_base, String fecha_fabricacion,
            String fecha_caducidad, int numero_lote, String pais_origen,
            String codigoOrganismo, String advertencias) {
        super(codigo, nombre, precio_base, fecha_fabricacion, fecha_caducidad, numero_lote, pais_origen);
        this.codigoOrganismo = codigoOrganismo;
        this.advertencias = advertencias;
    }

    public String getCodigoOrganismo() { return codigoOrganismo; }
    public String getAdvertencias()    { return advertencias; }

    @Override
    public String toString() {
        return "ProductosAmericanos [codigoOrganismo=" + codigoOrganismo + ", advertencias=" + advertencias + "]";
    }
}
