package com.clases;

import com.enumeracion.TipoAsiatico;

public abstract class CosmeticosAsiaticos extends Cosmetico {

    private String tipo_piel;
    private TipoAsiatico tipo;

    public CosmeticosAsiaticos(String codigo, String nombre, int precio_base, String fecha_fabricacion,
            String fecha_caducidad, int numero_lote, String pais_origen, String tipo_piel, TipoAsiatico tipo) {
        super(codigo, nombre, precio_base, fecha_fabricacion, fecha_caducidad, numero_lote, pais_origen);
        this.tipo_piel = tipo_piel;
        this.tipo = tipo;
    }

    public TipoAsiatico getTipo()         { return tipo; }
    public void setTipo(TipoAsiatico t)   { this.tipo = t; }
    public String getTipo_piel()          { return tipo_piel; }
    public void setTipo_piel(String t)    { this.tipo_piel = t; }

    @Override
    public String toString() {
        return "ProductosAsiaticos [tipo_piel=" + tipo_piel + ", tipo=" + tipo + "]";
    }
}
