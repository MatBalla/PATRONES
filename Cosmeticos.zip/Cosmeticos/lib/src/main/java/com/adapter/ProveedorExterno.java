package com.adapter;

import com.interfaces.ICosmeticos;

public class ProveedorExterno {

    public String[] getDatosProducto(String id) {
        return new String[]{"Perfume de Paris", "120", "Francia", "2024-01-01", "2027-01-01"};
    }
}
