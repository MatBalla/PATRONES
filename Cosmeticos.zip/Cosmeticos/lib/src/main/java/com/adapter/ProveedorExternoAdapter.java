package com.adapter;

import com.interfaces.ICosmeticos;

public class ProveedorExternoAdapter implements ICosmeticos {

    private ProveedorExterno proveedor;
    private String id;

    public ProveedorExternoAdapter(ProveedorExterno proveedor, String id) {
        this.proveedor = proveedor;
        this.id = id;
    }

    @Override
    public void informacion() {
        String[] datos = proveedor.getDatosProducto(id);
        System.out.println("  Adaptado - nombre: " + datos[0] + ", precio: " + datos[1] + ", origen: " + datos[2] + ", fabricacion: " + datos[3] + ", caducidad: " + datos[4]);
    }
}
