package com.interfaces;

public interface ICosmeticos {
    void informacion();
}
