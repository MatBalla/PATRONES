package com.main;

import com.adapter.ProveedorExterno;
import com.adapter.ProveedorExternoAdapter;
import com.clases.Cosmetico;
import com.decorator.*;
import com.enumeracion.TipoProducto;
import com.implementciones.FactoryConcreto;
import com.interfaces.ICosmeticos;
import com.state.CosmeticoContext;
import com.strategy.*;

public class Main {

    public static void main(String[] args) {
    	System.out.println("Tiendita de Cosméticos");
        System.out.println("-------------------------------------------------------------------------");

        FactoryConcreto factory = new FactoryConcreto();

        //Crear cosméticos
        ICosmeticos americano = factory.crearFactory(TipoProducto.COSMETICO_AMERICANO);
        americano.informacion();
        
        ICosmeticos permanente = factory.crearFactory(TipoProducto.COSMETICO_EUROPEO_PERMANENTE);
        permanente.informacion();
        
        ICosmeticos semipermanente = factory.crearFactory(TipoProducto.COSMETICO_EUROPEO_SEMIPERMANENTE);
        semipermanente.informacion();
        
        ICosmeticos facial = factory.crearFactory(TipoProducto.COSMETICO_ASIATICO_FACIAL);
        facial.informacion();
        
        ICosmeticos decorativa = factory.crearFactory(TipoProducto.COSMETICO_ASIATICO_DECORATIVA);
        decorativa.informacion();
        System.out.println("-------------------------------------------------------------------------");

        //Decorator
        ICosmeticos aniadirCosas = new EmpaqueEcologico(new CertificacionVegana(new ProteccionUV(permanente)));
        aniadirCosas.informacion();
        System.out.println("-------------------------------------------------------------------------");


        //Strategy
        Cosmetico cosmetico = (Cosmetico) factory.crearFactory(TipoProducto.COSMETICO_EUROPEO_PERMANENTE);
        CalculadorPrecio calc = new CalculadorPrecio(new MercadoLocal());
        calc.mostrarPrecio(cosmetico);

        calc.setEstrategia(new MercadoInternacional());
        calc.mostrarPrecio(cosmetico);

        calc.setEstrategia(new MercadoMayorista());
        calc.mostrarPrecio(cosmetico);
        System.out.println("-------------------------------------------------------------------------");


        //State
        CosmeticoContext ctx = new CosmeticoContext("Spiderman Tuti");
        ctx.vender();
        ctx.avanzar();
        ctx.vender();
        ctx.avanzar();
        ctx.vender();
        ctx.avanzar();
        ctx.vender();
        System.out.println("-------------------------------------------------------------------------");


        //Adapter
        ProveedorExterno externo = new ProveedorExterno();
        ICosmeticos adaptado = new ProveedorExternoAdapter(externo, "EXT-001");
        adaptado.informacion();
    }
}
