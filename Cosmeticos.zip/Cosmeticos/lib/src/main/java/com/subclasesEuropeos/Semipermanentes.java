package com.subclasesEuropeos;

import com.clases.CosmeticosEuropeos;

public class Semipermanentes extends CosmeticosEuropeos {

    private String tiempo;

    public Semipermanentes(String codigo, String nombre, int precio_base, String fecha_fabricacion,
            String fecha_caducidad, int numero_lote, String pais_origen, String norma, String tiempo) {
        super(codigo, nombre, precio_base, fecha_fabricacion, fecha_caducidad, numero_lote, pais_origen, norma);
        this.tiempo = tiempo;
    }

    public String getTiempo() { return tiempo; }

    @Override
    public void informacion() {
        System.out.println(toString());
    }

    @Override
    public String toString() {
        return "Semipermanentes [tiempo=" + tiempo + "]";
    }
}
