package com.subclasesEuropeos;

import com.clases.CosmeticosEuropeos;

public class Permanentes extends CosmeticosEuropeos {

    private String composicion_quimica;
    private String durabilidad;
    private int nivel_riesgo;

    public Permanentes(String codigo, String nombre, int precio_base, String fecha_fabricacion,
            String fecha_caducidad, int numero_lote, String pais_origen, String norma,
            String composicion_quimica, String durabilidad, int nivel_riesgo) {
        super(codigo, nombre, precio_base, fecha_fabricacion, fecha_caducidad, numero_lote, pais_origen, norma);
        this.composicion_quimica = composicion_quimica;
        this.durabilidad = durabilidad;
        this.nivel_riesgo = nivel_riesgo;
    }

    public String getComposicion_quimica() { return composicion_quimica; }
    public String getDurabilidad()         { return durabilidad; }
    public int getNivel_riesgo()           { return nivel_riesgo; }

    @Override
    public void informacion() {
        System.out.println(toString());
    }

    @Override
    public String toString() {
        return "Permanentes [composicion_quimica=" + composicion_quimica
                + ", durabilidad=" + durabilidad + ", nivel_riesgo=" + nivel_riesgo + "]";
    }
}
