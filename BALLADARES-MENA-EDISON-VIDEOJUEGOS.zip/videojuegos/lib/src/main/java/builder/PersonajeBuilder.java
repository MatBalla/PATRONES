package builder;

import ia.ComportamientoIA;
import modelo.Personaje;
import platforma.Plataforma;

public class PersonajeBuilder {

    private final Personaje personaje;

    public PersonajeBuilder() {
        this.personaje = new Personaje();
    }

    public PersonajeBuilder nombre(String nombre) {
        personaje.setNombre(nombre);
        return this;
    }

    public PersonajeBuilder tipo(String tipo) {
        personaje.setTipo(tipo);
        return this;
    }

    public PersonajeBuilder nivel(int nivel) {
        personaje.setNivel(nivel);
        return this;
    }

    public PersonajeBuilder puntosDeVida(int vida) {
        personaje.setPuntosDeVida(vida);
        return this;
    }

    public PersonajeBuilder ataque(int ataque) {
        personaje.setAtaque(ataque);
        return this;
    }

    public PersonajeBuilder defensa(int defensa) {
        personaje.setDefensa(defensa);
        return this;
    }

    public PersonajeBuilder plataforma(Plataforma plataforma) {
        personaje.setPlataforma(plataforma);
        return this;
    }

    public PersonajeBuilder comportamientoIA(ComportamientoIA ia) {
        personaje.setComportamientoIA(ia);
        return this;
    }

    public PersonajeBuilder arma(String arma) {
        personaje.getInventario().agregarArma(arma);
        return this;
    }

    public PersonajeBuilder armadura(String armadura) {
        personaje.getInventario().agregarArmadura(armadura);
        return this;
    }

    public PersonajeBuilder pocion(String pocion) {
        personaje.getInventario().agregarPocion(pocion);
        return this;
    }

    public PersonajeBuilder habilidadEspecial(String habilidad) {
        personaje.getHabilidades().agregarHabilidadEspecial(habilidad);
        return this;
    }

    public PersonajeBuilder ataqueEspecial(String ataque) {
        personaje.getHabilidades().configurarAtaqueEspecial(ataque);
        return this;
    }

    public Personaje build() {
        if (personaje.getNombre() == null) {
            throw new IllegalStateException("El personaje debe poseer nombre");
        }
        
        System.out.println("Personaje creado: " + personaje.getNombre() + " , de tipo: " + personaje.getTipo());
        return personaje;
    }
}
