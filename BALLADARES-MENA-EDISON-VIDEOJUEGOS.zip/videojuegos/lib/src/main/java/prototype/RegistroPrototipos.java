package prototype;

import java.util.HashMap;
import java.util.Map;

import modelo.Personaje;

public class RegistroPrototipos {

    private static final Map<String, Personaje> registro = new HashMap<>();

    public static void registrar(String clave, Personaje personaje) {
        registro.put(clave, personaje);
        System.out.println("Registrado prototipo: " + clave);
    }

    public static Personaje clonar(String cl) {
        Personaje prototipo = registro.get(cl);
        if (prototipo == null) {
            System.out.println("Prototipo no encontrado: ");
        }
        Personaje clon = prototipo.clone();
        System.out.println("Clonado desde: " + cl);
        return clon;
    }

    public static void listarPrototipos() {
        System.out.println("  Prototipos registrados: " + registro.keySet());
    }
}
