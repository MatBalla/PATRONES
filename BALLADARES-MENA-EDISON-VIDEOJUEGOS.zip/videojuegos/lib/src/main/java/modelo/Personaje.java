package modelo;

import platforma.Plataforma;

import java.util.ArrayList;
import java.util.List;

import HabilidadesEsp.Habilidades;
import ia.ComportamientoIA;
import inventario.Inventario;

public class Personaje implements Cloneable {

    private String nombre;
    private int nivel;
    private int puntosDeVida;
    private int ataque;
    private int defensa;
    private String tipo;
    private Plataforma plataforma;
    private Inventario inventario;
    private Habilidades habilidades;
    private ComportamientoIA comportamientoIA;

    public Personaje() {
        this.inventario  = new Inventario();
        this.habilidades = new Habilidades();
    }
    
    

    public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public int getNivel() {
		return nivel;
	}



	public void setNivel(int nivel) {
		this.nivel = nivel;
	}



	public int getPuntosDeVida() {
		return puntosDeVida;
	}



	public void setPuntosDeVida(int puntosDeVida) {
		this.puntosDeVida = puntosDeVida;
	}



	public int getAtaque() {
		return ataque;
	}



	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}



	public int getDefensa() {
		return defensa;
	}



	public void setDefensa(int defensa) {
		this.defensa = defensa;
	}



	public String getTipo() {
		return tipo;
	}



	public void setTipo(String tipo) {
		this.tipo = tipo;
	}



	public Plataforma getPlataforma() {
		return plataforma;
	}



	public void setPlataforma(Plataforma plataforma) {
		this.plataforma = plataforma;
	}



	public Inventario getInventario() {
		return inventario;
	}



	public void setInventario(Inventario inventario) {
		this.inventario = inventario;
	}



	public Habilidades getHabilidades() {
		return habilidades;
	}



	public void setHabilidades(Habilidades habilidades) {
		this.habilidades = habilidades;
	}



	public ComportamientoIA getComportamientoIA() {
		return comportamientoIA;
	}



	public void setComportamientoIA(ComportamientoIA comportamientoIA) {
		this.comportamientoIA = comportamientoIA;
	}



	@Override
	public String toString() {
		return "Personaje [nombre=" + nombre + ", nivel=" + nivel + ", puntosDeVida=" + puntosDeVida + ", ataque="
				+ ataque + ", defensa=" + defensa + ", tipo=" + tipo + ", plataforma=" + plataforma + ", inventario="
				+ inventario + ", habilidades=" + habilidades + ", comportamientoIA=" + comportamientoIA + "]";
	}



	//prototype
    @Override
    public Personaje clone() {
        try {
            Personaje clon = (Personaje) super.clone();
            clon.habilidades = this.habilidades.clone();
            return clon;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }

    
}
