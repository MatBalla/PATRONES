package main;

import builder.PersonajeBuilder;
import factory.*;
import ia.*;
import modelo.Personaje;
import platforma.*;
import prototype.RegistroPrototipos;

public class Main {

    public static void main(String[] args) {

    	System.out.println("----------------------------------------------------------");
        ///////////////////////////////////////////////////////////////////////////
        Plataforma pc      = new PlataformaPC();
        Plataforma mobile  = new PlataformaMobil();
        Plataforma consola = new PlataformaConsola();

        pc.mostrar();
        mobile.mostrar();
        consola.mostrar();

         ///////////////////////////////////////////////////////////////////////////

        
        PersonajeFactory guerreroF = new GuerreroFactory();
        Personaje guerreroPC = guerreroF.crearYConfigurar("Jose", pc);
        System.out.println(guerreroPC);
    	System.out.println("----------------------------------------------------------");

        
        PersonajeFactory magoF = new MagoFactory();
        Personaje magoConsola = magoF.crearYConfigurar("Gargamelf", consola);
        System.out.println(magoConsola);
    	System.out.println("----------------------------------------------------------");

        
        PersonajeFactory arqueroF = new ArqueroFactory();
        Personaje arqueroMobil = arqueroF.crearYConfigurar("Ojo de halcon", mobile);
        System.out.println(arqueroMobil);
    	System.out.println("----------------------------------------------------------");
        
        PersonajeFactory enemigoF = new EnemigоFactory();
        Personaje enemigoPC = enemigoF.crearYConfigurar("Creeper",pc);
        System.out.println(enemigoPC);
    	System.out.println("----------------------------------------------------------");

        
        PersonajeFactory jefeF = new BossFactory();
        Personaje jefeConsola = jefeF.crearYConfigurar("Zeus",consola);
        System.out.println(jefeConsola);
    	System.out.println("----------------------------------------------------------");

        
    	System.out.println("----------------------------------------------------------");
        ///////////////////////////////////////////////////////////////////////////////
        //INVENTARIOS
        System.out.println("JOSE");
        guerreroPC.getInventario().inventario();
        guerreroPC.getHabilidades().mostrarHabilidades();
        guerreroPC.getComportamientoIA().ejecutar(guerreroPC.getNombre());
    	System.out.println("----------------------------------------------------------");
        
        System.out.println("GARGAMEL");
        magoConsola.getInventario().inventario();
        magoConsola.getHabilidades().mostrarHabilidades();
        magoConsola.getComportamientoIA().ejecutar(magoConsola.getNombre());
    	System.out.println("----------------------------------------------------------");

        
        System.out.println("OJO DE HALCON");
        arqueroMobil.getInventario().inventario();
        arqueroMobil.getHabilidades().mostrarHabilidades();
        arqueroMobil.getComportamientoIA().ejecutar(arqueroMobil.getNombre());
    	System.out.println("----------------------------------------------------------");

        System.out.println("CREEPER");
        enemigoPC.getInventario().inventario();
        enemigoPC.getHabilidades().mostrarHabilidades();
        enemigoPC.getComportamientoIA().ejecutar(enemigoPC.getNombre());
    	System.out.println("----------------------------------------------------------");

        System.out.println("ZEUS");
        jefeConsola.getInventario().inventario();
        jefeConsola.getHabilidades().mostrarHabilidades();
        jefeConsola.getComportamientoIA().ejecutar(jefeConsola.getNombre());
    	System.out.println("----------------------------------------------------------");

        //////////////////////////////////////////////////////////////////////////////
    	System.out.println("----------------------------------------------------------");

        Personaje personajeB1 = new PersonajeBuilder()
                .nombre("XRL8")
                .tipo("aliwn")
                .nivel(25)
                .puntosDeVida(180)
                .ataque(110)
                .defensa(50)
                .plataforma(pc)
                .comportamientoIA(new IAEstrategico())
                .arma("garras")
                .armadura("desconocido")
                .habilidadEspecial("regeneracion")
                .ataqueEspecial("oido absoluto")
                .build();

        System.out.println(personajeB1);
        personajeB1.getInventario().inventario();
        personajeB1.getHabilidades().mostrarHabilidades();
        personajeB1.getComportamientoIA().ejecutar(personajeB1.getNombre());
    	System.out.println("----------------------------------------------------------");

        //////////////////////////////////////////////////////////////////////////
        /// 
    	System.out.println("----------------------------------------------------------");

        
        RegistroPrototipos.registrar("creeper", enemigoPC);
        RegistroPrototipos.listarPrototipos();
        System.out.println("Original: " + enemigoPC);

        Personaje creper11 = RegistroPrototipos.clonar("creeper");//clon 1
        creper11.setNombre("creeper cargado");
        creper11.setNivel(5);
        creper11.setPuntosDeVida(creper11.getPuntosDeVida() + 50);
        creper11.setAtaque(creper11.getAtaque() + 20);
        creper11.getInventario().agregarArma("polvora");
        creper11.getInventario().agregarArmadura("armadura de fosforo");
        creper11.getHabilidades().agregarHabilidadEspecial("explosion");
        System.out.println("Copia 1: " + creper11);//mostrar
        creper11.getInventario().inventario();
        creper11.getHabilidades().mostrarHabilidades();
    	System.out.println("----------------------------------------------------------");


        Personaje creeper12 = RegistroPrototipos.clonar("creeper");
        creeper12.setNombre("creeper supercargado");
        creeper12.setNivel(20);
        creeper12.setPuntosDeVida(creeper12.getPuntosDeVida() + 100);
        creeper12.setAtaque(creeper12.getAtaque() + 80);
        creeper12.setComportamientoIA(new IAEstrategico());
        creeper12.getInventario().agregarArma("Rayo");
        creeper12.getHabilidades().agregarHabilidadEspecial("esquivar golpes");
        creeper12.getHabilidades().configurarAtaqueEspecial("explosion supercatgada");
        System.out.println("Copia 2: " + creeper12);//mostrar
        creeper12.getInventario().inventario();
        creeper12.getHabilidades().mostrarHabilidades();
        creeper12.getComportamientoIA().ejecutar(creeper12.getNombre());

        

    }

}
