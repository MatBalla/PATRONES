package platforma;

public class PlataformaMobil implements Plataforma {

    
    @Override 
    public String getNombre(){
    	return "Mobil"; 
    }
    
    @Override 
    public int getCalidadGrafica(){
    	return 60; 
    }
    
    @Override 
    public double getDificultad(){ 
    	return 0.9; 
    }
    
    @Override 
    public int getCantidadEnemigos(){ 
    	return 30; 
    }
    
    @Override 
    public int getMemoriaMB(){ 
    	return 2048; 
    }
    
    @Override 
    public double getVelocidadAnimacion(){ 
    	return 0.95; 
    }

    @Override
    public void mostrar() {
        System.out.println("PlataformaMobil [getNombre()=" + getNombre() + ", getCalidadGrafica()=" + getCalidadGrafica()
		+ ", getDificultad()=" + getDificultad() + ", getCantidadEnemigos()=" + getCantidadEnemigos()
		+ ", getMemoriaMB()=" + getMemoriaMB() + ", getVelocidadAnimacion()=" + getVelocidadAnimacion() + "]");
    }
}
