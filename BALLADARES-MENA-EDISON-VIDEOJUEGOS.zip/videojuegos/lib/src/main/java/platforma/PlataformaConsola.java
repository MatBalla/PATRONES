package platforma;

public class PlataformaConsola implements Plataforma {

    @Override 
    public String getNombre(){
    	return "Consola"; 
    }
    
    @Override 
    public int getCalidadGrafica(){
    	return 60; 
    }
    
    @Override 
    public double getDificultad(){ 
    	return 0.9; 
    }
    
    @Override 
    public int getCantidadEnemigos(){ 
    	return 30; 
    }
    
    @Override 
    public int getMemoriaMB(){ 
    	return 2048; 
    }
    
    @Override 
    public double getVelocidadAnimacion(){ 
    	return 0.95; 
    }

    @Override
    public void mostrar() {
        System.out.println("PlataformaConsola [getNombre()=" + getNombre() + ", getCalidadGrafica()=" + getCalidadGrafica()
		+ ", getDificultad()=" + getDificultad() + ", getCantidadEnemigos()=" + getCantidadEnemigos()
		+ ", getMemoriaMB()=" + getMemoriaMB() + ", getVelocidadAnimacion()=" + getVelocidadAnimacion() + "]");
    }

	
    
}
