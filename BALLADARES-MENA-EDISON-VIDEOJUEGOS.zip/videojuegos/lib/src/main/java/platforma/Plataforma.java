package platforma;

public interface Plataforma {
    public String getNombre();
    public int    getCalidadGrafica();     
    public double getDificultad();         
    public int    getCantidadEnemigos();
    public int    getMemoriaMB();
    public double getVelocidadAnimacion();
    public void   mostrar();
}
