package factory;

import ia.IAAgresivo;
import modelo.Personaje;
import platforma.Plataforma;

public class EnemigоFactory extends PersonajeFactory {

    @Override
    public Personaje crearPersonaje(String nombre, Plataforma plataforma) {
    	
        Personaje e = new Personaje();
        e.setNombre(nombre);
        e.setTipo("Enemigo");
        e.setNivel(2);
        e.setPuntosDeVida((int)(60 * plataforma.getDificultad()));
        e.setAtaque((int)(40 * plataforma.getDificultad()));
        e.setDefensa((int)(25 * plataforma.getDificultad()));
        e.setComportamientoIA(new IAAgresivo());
        e.getInventario().agregarArma("puñalada");
        return e;
    }
}
