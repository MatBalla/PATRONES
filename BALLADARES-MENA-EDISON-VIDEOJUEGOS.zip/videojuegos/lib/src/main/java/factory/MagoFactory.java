package factory;

import ia.IAEstrategico;
import modelo.Personaje;
import platforma.Plataforma;

public class MagoFactory extends PersonajeFactory {

    @Override
    public Personaje crearPersonaje(String nombre, Plataforma plataforma) {
    	
        Personaje m = new Personaje();
        m.setNombre(nombre);
        m.setTipo("Mago");
        m.setNivel(1);
        m.setPuntosDeVida(80);
        m.setAtaque((int)(120 * plataforma.getDificultad()));
        m.setDefensa((int)(20 * plataforma.getDificultad()));
        m.setComportamientoIA(new IAEstrategico());
        m.getInventario().agregarArma("varita magica");
        m.getInventario().agregarPocion("regeneracion");
        m.getHabilidades().agregarHabilidadEspecial("invocacion");
        m.getHabilidades().configurarAtaqueEspecial("especto patronus");
        return m;
    }
}
