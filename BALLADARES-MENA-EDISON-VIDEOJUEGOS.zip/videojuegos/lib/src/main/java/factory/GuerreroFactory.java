package factory;

import ia.IAAgresivo;
import modelo.Personaje;
import platforma.Plataforma;

public class GuerreroFactory extends PersonajeFactory {

    @Override
    public Personaje crearPersonaje(String nombre, Plataforma plataforma) {
        
    	Personaje g = new Personaje();
        g.setNombre(nombre);
        g.setTipo("Guerrero");
        g.setNivel(1);
        g.setPuntosDeVida(150);
        g.setAtaque((int)(80 * plataforma.getDificultad()));
        g.setDefensa((int)(60 * plataforma.getDificultad()));
        g.setComportamientoIA(new IAAgresivo());
        g.getInventario().agregarArma("lanza");
        g.getInventario().agregarArmadura("pechera de cuero");
        g.getHabilidades().agregarHabilidadEspecial("lanzamiento");
        g.getHabilidades().configurarAtaqueEspecial("lanzamiento multiple");
        return g;
    }
}
