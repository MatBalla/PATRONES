package factory;

import ia.IAEstrategico;
import modelo.Personaje;
import platforma.Plataforma;

public class BossFactory extends PersonajeFactory {

    @Override
    public Personaje crearPersonaje(String nombre, Plataforma plataforma) {
    	
        Personaje b = new Personaje();
        b.setNombre(nombre);
        b.setTipo("Jefe");
        b.setNivel(100);
        b.setPuntosDeVida((int)(2000 * plataforma.getDificultad()));
        b.setAtaque((int)(300 * plataforma.getDificultad()));
        b.setDefensa((int)(200 * plataforma.getDificultad()));
        b.setComportamientoIA(new IAEstrategico());
        b.getInventario().agregarArma("martillo de odin");
        b.getInventario().agregarArmadura("cota de malla");
        b.getHabilidades().agregarHabilidadEspecial("rompesuelos");
        b.getHabilidades().agregarHabilidadEspecial("carga devastadora");
        return b;
    }
}
