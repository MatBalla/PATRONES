package factory;

import modelo.Personaje;
import platforma.Plataforma;

public abstract class PersonajeFactory {

    public abstract Personaje crearPersonaje(String nombre, Plataforma plataforma); //implementan las clases

    public Personaje crearYConfigurar(String nombre, Plataforma plataforma) { ///molde para creacion
    
        Personaje p = crearPersonaje(nombre, plataforma);
        p.setPlataforma(plataforma);
        System.out.println("Personaje creado: " + p.getNombre() + " , de tipo:" + p.getTipo() + " para la plataforma: " + plataforma.getNombre());
        return p;
    }
}
