package factory;

import ia.IADefensivo;
import modelo.Personaje;
import platforma.Plataforma;

public class ArqueroFactory extends PersonajeFactory {

    @Override
    public Personaje crearPersonaje(String nombre, Plataforma plataforma) {
    	
        Personaje a = new Personaje();
        a.setNombre(nombre);
        a.setTipo("Arquero");
        a.setNivel(1);
        a.setPuntosDeVida(100);
        a.setAtaque((int)(90 * plataforma.getDificultad()));
        a.setDefensa((int)(35 * plataforma.getDificultad()));
        a.setComportamientoIA(new IADefensivo());
        a.getInventario().agregarArma("arco");
        a.getInventario().agregarArma("flehcas");
        a.getHabilidades().agregarHabilidadEspecial("flecha brillante");
        a.getHabilidades().configurarAtaqueEspecial("disparo tornado");
        return a;
    }
}
