package ia;

public class IAEstrategico implements ComportamientoIA {
    
    @Override 
   	public String getNombreComportamiento() { 
   		return "Estrategico"; 
   	
   	}
       
   	@Override 
   	public void ejecutar(String nombre) {
           System.out.println("Ia estrategico: " + nombre + " planea tacticas");
    }
}
