package ia;

public class IAAgresivo implements ComportamientoIA {
    
	@Override 
	public String getNombreComportamiento() { 
		return "Agresivo"; 
	
	}
    
	@Override 
	public void ejecutar(String nombre) {
        System.out.println("Ia agresiva: " + nombre + " ataca");
    }
}
