package ia;

public class IADefensivo implements ComportamientoIA {
	
    @Override 
	public String getNombreComportamiento() { 
		return "Defensivo"; 
	
	}
    
	@Override 
	public void ejecutar(String nombre) {
        System.out.println("Ia defensiva: " + nombre + " defiende");
    }
}
