package ia;

public class IAPasivo implements ComportamientoIA {
    
    @Override 
   	public String getNombreComportamiento() { 
   		return "Pasivo"; 
   	
   	}
       
   	@Override 
   	public void ejecutar(String nombre) {
           System.out.println("Ia pasivo: " + nombre + " esta tranquilo");
    }
}
