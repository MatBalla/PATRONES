package ia;

public interface ComportamientoIA {
	
    String getNombreComportamiento();
    void ejecutar(String nombrePersonaje);

}
