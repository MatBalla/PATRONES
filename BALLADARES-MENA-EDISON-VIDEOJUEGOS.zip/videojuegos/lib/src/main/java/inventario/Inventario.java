package inventario;

import java.util.ArrayList;
import java.util.List;

public class Inventario implements Cloneable {

	private List<String> armas     = new ArrayList<>();
	private List<String> armaduras = new ArrayList<>();
	private List<String> pociones  = new ArrayList<>();

	public void agregarArma(String arma){
		armas.add(arma); 
	}
	
	public void agregarArmadura(String armadura){
		armaduras.add(armadura); 
	}
	
	public void agregarPocion(String pocion){
		pociones.add(pocion);
	}

	public void inventario() {
		System.out.println("Inventario");
		System.out.println("Armas    : " + armas);
		System.out.println("Armaduras: " + armaduras);
		System.out.println("Pociones : " + pociones);
	}

}
