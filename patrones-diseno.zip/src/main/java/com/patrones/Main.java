package com.patrones;

import com.patrones.comportamentales.*;
import com.patrones.creacionales.*;
import com.patrones.dominio.*;
import com.patrones.estructurales.*;

import java.util.List;

// ═══════════════════════════════════════════════════════════════
//  MAIN: todos los patrones interactuando sobre el mismo dominio
//
//  FLUJO DEL SISTEMA:
//  1. Singleton provee la configuración global
//  2. Factory Method / Abstract Factory crean objetos
//  3. Builder construye el pedido paso a paso
//  4. Adapter integra datos de proveedor externo
//  5. Decorator añade características al producto
//  6. Facade simplifica el checkout complejo
//  7. Proxy añade caché al catálogo
//  8. Composite organiza el catálogo en árbol
//  9. Strategy define el algoritmo de descuento
// 10. State controla el ciclo de vida del pedido
// 11. Observer notifica a los suscriptores
// 12. Command encapsula acciones con soporte de undo
// 13. Template Method exporta el reporte en distintos formatos
// 14. Iterator recorre el catálogo sin exponer su estructura
// ═══════════════════════════════════════════════════════════════

public class Main {

    public static void main(String[] args) {

        // ── 1. SINGLETON ─────────────────────────────────────────────
        titulo("1. SINGLETON — una sola instancia global");
        ConfiguracionTienda config = ConfiguracionTienda.getInstance();
        ConfiguracionTienda mismo  = ConfiguracionTienda.getInstance(); // misma referencia
        System.out.println("  Misma instancia: " + (config == mismo));  // true
        System.out.println("  " + config);

        // ── 2. FACTORY METHOD ─────────────────────────────────────────
        titulo("2. FACTORY METHOD — subclases deciden qué crear");
        CreadorProducto creadorE = FactoryMethod.obtenerCreador("electronico");
        CreadorProducto creadorA = FactoryMethod.obtenerCreador("alimento");
        creadorE.mostrarProducto("Smartphone", 500.00);
        creadorA.mostrarProducto("Yogur griego", 3.50);

        // ── 3. ABSTRACT FACTORY ───────────────────────────────────────
        titulo("3. ABSTRACT FACTORY — familias de objetos relacionados");
        // El cliente decide el tema y la fábrica crea la familia completa
        FabricaUI fabOscura = AbstractFactory.obtenerFabrica("oscuro");
        FabricaUI fabClara  = AbstractFactory.obtenerFabrica("claro");
        System.out.println("  Tema oscuro:");
        AbstractFactory.renderizarUI(fabOscura);
        System.out.println("  Tema claro:");
        AbstractFactory.renderizarUI(fabClara);

        // ── 4. BUILDER ────────────────────────────────────────────────
        titulo("4. BUILDER — construcción paso a paso con fluent API");
        Producto laptop   = new Producto("Laptop Pro", 1200.00, "electronico");
        Producto auricular = new Producto("Auriculares BT", 80.00, "electronico");
        Producto libro    = new Producto("Clean Code", 35.00, "libro");

        // Los patrones se encadenan: Builder construye el Pedido
        // que luego usarán Strategy, State, Observer, Command, Template
        Pedido pedido = new PedidoBuilder("ORD-001")
                .agregarProducto(laptop)
                .agregarProducto(auricular)
                .conDescuento("PROMO10")
                .envioExpress()
                .build();

        // ── 5. ADAPTER ────────────────────────────────────────────────
        titulo("5. ADAPTER — interfaz incompatible → interfaz esperada");
        Adapter.demo();

        // ── 6. DECORATOR ──────────────────────────────────────────────
        titulo("6. DECORATOR — añadir características dinámicamente");
        // El mismo Producto del Builder ahora se decora
        Decorator.demo(laptop);

        // ── 7. FACADE ─────────────────────────────────────────────────
        titulo("7. FACADE — interfaz simple sobre subsistema complejo");
        CheckoutFacade checkout = new CheckoutFacade();
        // Una sola llamada coordina inventario, pago, envío y notificación
        checkout.completarCompra(pedido, "4321-xxxx-xxxx-5678",
                "Av. Principal 123", "cliente@email.com");

        // ── 8. PROXY ──────────────────────────────────────────────────
        titulo("8. PROXY — controlar acceso (aquí: caché)");
        CatalogoProxy.demo();

        // ── 9. COMPOSITE ──────────────────────────────────────────────
        titulo("9. COMPOSITE — árbol de categorías (hoja = grupo)");
        Composite.demo();

        // ── 10. STRATEGY ──────────────────────────────────────────────
        titulo("10. STRATEGY — algoritmo intercambiable en runtime");
        // Mismo pedido, distintas estrategias de descuento
        CalculadoraPrecio calc = Strategy.calculadora(Strategy.sinDescuento());
        calc.calcular(pedido);
        calc.setEstrategia(Strategy.porcentaje(15));  // cambio en runtime
        calc.calcular(pedido);
        calc.setEstrategia(Strategy.fijo(50));
        calc.calcular(pedido);

        // ── 11. STATE ─────────────────────────────────────────────────
        titulo("11. STATE — comportamiento según estado del ciclo de vida");
        ContextoPedido ctx = new ContextoPedido(pedido);
        ctx.enviar();    // ✗ no se puede sin pagar
        ctx.pagar();     // Pendiente → Pagado
        ctx.enviar();    // Pagado → Enviado
        ctx.entregar();  // Enviado → Entregado
        ctx.cancelar();  // ✗ ya fue entregado

        // ── 12. OBSERVER ──────────────────────────────────────────────
        titulo("12. OBSERVER — notificar a múltiples suscriptores");
        GestorPedidos gestor = ObserverDemo.crearGestor();
        Pedido pedido2 = new Pedido("ORD-002");
        pedido2.agregar(libro);
        gestor.realizarPedido(pedido2);  // dispara notificación a todos los observers

        // ── 13. COMMAND ───────────────────────────────────────────────
        titulo("13. COMMAND — acciones encapsuladas con soporte undo");
        Pedido carrito = new Pedido("CARRITO-001");
        CommandDemo.demo(carrito, laptop, auricular);

        // ── 14. TEMPLATE METHOD ───────────────────────────────────────
        titulo("14. TEMPLATE METHOD — esqueleto fijo, detalles variables");
        List<Pedido> pedidos = List.of(pedido, pedido2);
        System.out.println("  — Formato CSV:");
        TemplateMethodDemo.csv().generar(pedidos);
        System.out.println("  — Formato HTML:");
        TemplateMethodDemo.html().generar(pedidos);

        // ── 15. ITERATOR ──────────────────────────────────────────────
        titulo("15. ITERATOR — recorrer colección sin exponer estructura");
        List<Producto> catalogo = List.of(
            laptop, auricular, libro,
            new Producto("Mouse", 25.00, "electronico"),
            new Producto("Pan integral", 2.50, "alimento")
        );
        IteratorDemo.demo(catalogo);
    }

    // ─── helper ──────────────────────────────────────────────────
    private static void titulo(String s) {
        System.out.println("\n" + "═".repeat(60));
        System.out.println("  " + s);
        System.out.println("═".repeat(60));
    }
}
