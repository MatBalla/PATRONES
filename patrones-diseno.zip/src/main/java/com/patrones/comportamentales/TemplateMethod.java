package com.patrones.comportamentales;

import com.patrones.dominio.Pedido;
import java.util.List;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: TEMPLATE METHOD
//  ¿Cuándo? Cuando tienes un algoritmo con pasos fijos pero
//  algunos de esos pasos varían según el contexto.
//  La clase base define el ESQUELETO del algoritmo,
//  las subclases implementan solo los pasos variables.
//  Diferencia con Strategy: Template Method usa herencia,
//  Strategy usa composición.
//  Estructura:
//    - Clase abstracta con templateMethod() que llama los pasos
//    - Pasos invariantes: implementados en la clase base
//    - Pasos variables (abstract): implementados en subclases
// ═══════════════════════════════════════════════════════════════

// 1. Clase abstracta con el template method
public abstract class GeneradorReporte {

    // El template method: define el esqueleto, no se sobreescribe (final)
    public final void generar(List<Pedido> pedidos) {
        inicializar();                    // paso fijo
        escribirEncabezado();             // paso variable (abstracto)
        pedidos.forEach(this::escribirFila);  // paso variable (abstracto)
        escribirPie(calcularTotal(pedidos)); // paso fijo + hook
        finalizar();                      // paso fijo
    }

    // Pasos invariantes: implementados aquí
    private void inicializar() {
        System.out.println("  [Template] Iniciando generación de reporte...");
    }
    private void finalizar() {
        System.out.println("  [Template] Reporte completado.");
    }
    private double calcularTotal(List<Pedido> pedidos) {
        return pedidos.stream().mapToDouble(Pedido::total).sum();
    }

    // Pasos variables: las subclases deciden el formato
    protected abstract void escribirEncabezado();
    protected abstract void escribirFila(Pedido pedido);
    protected abstract void escribirPie(double total);
}

// 2. Subclase para formato CSV
class ReporteCSV extends GeneradorReporte {
    @Override protected void escribirEncabezado() {
        System.out.println("  [Template→CSV] id,items,total");
    }
    @Override protected void escribirFila(Pedido p) {
        System.out.printf("  [Template→CSV] %s,%d,%.2f%n", p.getId(), p.getItems().size(), p.total());
    }
    @Override protected void escribirPie(double total) {
        System.out.printf("  [Template→CSV] TOTAL,,%.2f%n", total);
    }
}

// 3. Subclase para formato HTML
class ReporteHTML extends GeneradorReporte {
    @Override protected void escribirEncabezado() {
        System.out.println("  [Template→HTML] <table><tr><th>ID</th><th>Items</th><th>Total</th></tr>");
    }
    @Override protected void escribirFila(Pedido p) {
        System.out.printf("  [Template→HTML] <tr><td>%s</td><td>%d</td><td>$%.2f</td></tr>%n",
                p.getId(), p.getItems().size(), p.total());
    }
    @Override protected void escribirPie(double total) {
        System.out.printf("  [Template→HTML] </table><p>Total: $%.2f</p>%n", total);
    }
}

// 4. Clase de entrada para el demo
public class TemplateMethodDemo {
    public static GeneradorReporte csv()  { return new ReporteCSV();  }
    public static GeneradorReporte html() { return new ReporteHTML(); }
}
