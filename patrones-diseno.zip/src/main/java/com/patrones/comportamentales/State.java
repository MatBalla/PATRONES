package com.patrones.comportamentales;

import com.patrones.dominio.Pedido;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: STATE
//  ¿Cuándo? Cuando un objeto cambia su comportamiento según
//  su estado interno y los estados tienen transiciones claras.
//  Diferencia con Strategy: Strategy es un algoritmo elegido
//  externamente; State gestiona transiciones internas.
//  Estructura:
//    - Interfaz State con todas las acciones posibles
//    - Clases concretas: una por estado
//    - Contexto: tiene un State actual y delega operaciones
// ═══════════════════════════════════════════════════════════════

// 1. Interfaz State
interface EstadoPedido {
    void pagar(ContextoPedido ctx);
    void enviar(ContextoPedido ctx);
    void entregar(ContextoPedido ctx);
    void cancelar(ContextoPedido ctx);
    String getNombre();
}

// 2. Contexto: el objeto cuyo comportamiento cambia
public class ContextoPedido {

    private EstadoPedido estado;
    private final Pedido pedido;

    public ContextoPedido(Pedido p) {
        this.pedido = p;
        this.estado = new EstadoPendiente();  // estado inicial
        System.out.println("  [State] Pedido creado en estado: " + estado.getNombre());
    }

    // Delegación: el contexto no sabe qué hace cada acción
    public void pagar()    { estado.pagar(this);    }
    public void enviar()   { estado.enviar(this);   }
    public void entregar() { estado.entregar(this); }
    public void cancelar() { estado.cancelar(this); }

    // El estado se actualiza a sí mismo vía este método
    public void setEstado(EstadoPedido nuevoEstado) {
        System.out.println("  [State] Transición: " + estado.getNombre()
                + " → " + nuevoEstado.getNombre());
        this.estado = nuevoEstado;
    }

    public String getEstadoActual() { return estado.getNombre(); }
}

// 3. Estados concretos — cada uno implementa las transiciones válidas

class EstadoPendiente implements EstadoPedido {
    @Override public String getNombre() { return "Pendiente"; }
    @Override public void pagar(ContextoPedido ctx) {
        ctx.setEstado(new EstadoPagado());
    }
    @Override public void enviar(ContextoPedido ctx) {
        System.out.println("  [State] ✗ No puedes enviar un pedido sin pagar");
    }
    @Override public void entregar(ContextoPedido ctx) {
        System.out.println("  [State] ✗ No puedes entregar sin enviar");
    }
    @Override public void cancelar(ContextoPedido ctx) {
        ctx.setEstado(new EstadoCancelado());
    }
}

class EstadoPagado implements EstadoPedido {
    @Override public String getNombre() { return "Pagado"; }
    @Override public void pagar(ContextoPedido ctx) {
        System.out.println("  [State] ✗ Ya fue pagado");
    }
    @Override public void enviar(ContextoPedido ctx) {
        ctx.setEstado(new EstadoEnviado());
    }
    @Override public void entregar(ContextoPedido ctx) {
        System.out.println("  [State] ✗ Primero debe enviarse");
    }
    @Override public void cancelar(ContextoPedido ctx) {
        ctx.setEstado(new EstadoCancelado());
    }
}

class EstadoEnviado implements EstadoPedido {
    @Override public String getNombre() { return "Enviado"; }
    @Override public void pagar(ContextoPedido ctx)    { System.out.println("  [State] ✗ Ya fue pagado"); }
    @Override public void enviar(ContextoPedido ctx)   { System.out.println("  [State] ✗ Ya fue enviado"); }
    @Override public void entregar(ContextoPedido ctx) { ctx.setEstado(new EstadoEntregado()); }
    @Override public void cancelar(ContextoPedido ctx) { System.out.println("  [State] ✗ No se puede cancelar en tránsito"); }
}

class EstadoEntregado implements EstadoPedido {
    @Override public String getNombre() { return "Entregado"; }
    @Override public void pagar(ContextoPedido ctx)    { System.out.println("  [State] ✗ Pedido finalizado"); }
    @Override public void enviar(ContextoPedido ctx)   { System.out.println("  [State] ✗ Pedido finalizado"); }
    @Override public void entregar(ContextoPedido ctx) { System.out.println("  [State] ✗ Ya fue entregado"); }
    @Override public void cancelar(ContextoPedido ctx) { System.out.println("  [State] ✗ No puedes cancelar un pedido entregado"); }
}

class EstadoCancelado implements EstadoPedido {
    @Override public String getNombre() { return "Cancelado"; }
    @Override public void pagar(ContextoPedido ctx)    { System.out.println("  [State] ✗ Pedido cancelado"); }
    @Override public void enviar(ContextoPedido ctx)   { System.out.println("  [State] ✗ Pedido cancelado"); }
    @Override public void entregar(ContextoPedido ctx) { System.out.println("  [State] ✗ Pedido cancelado"); }
    @Override public void cancelar(ContextoPedido ctx) { System.out.println("  [State] ✗ Ya está cancelado"); }
}
