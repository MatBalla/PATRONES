package com.patrones.comportamentales;

import com.patrones.dominio.Pedido;
import com.patrones.dominio.Producto;
import java.util.ArrayDeque;
import java.util.Deque;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: COMMAND
//  ¿Cuándo? Cuando quieres encapsular una acción como objeto
//  para poder: ejecutarla, deshacerla (undo), guardarla,
//  encolarla o ejecutarla más tarde.
//  Estructura:
//    - Interfaz Command con execute() y undo()
//    - Comandos concretos encapsulan la operación y su inversa
//    - Invoker: ejecuta comandos y mantiene historial para undo
//    - Receiver: el objeto que realmente hace el trabajo
// ═══════════════════════════════════════════════════════════════

// 1. Interfaz Command
public interface Command {
    void execute();
    void undo();
}

// 2. Comandos concretos (el Receiver es Pedido)

class AgregarAlCarrito implements Command {
    private final Pedido  pedido;  // receiver
    private final Producto producto;

    public AgregarAlCarrito(Pedido pedido, Producto producto) {
        this.pedido   = pedido;
        this.producto = producto;
    }

    @Override public void execute() {
        pedido.agregar(producto);
        System.out.println("  [Command] Agregado: " + producto.getNombre());
    }

    @Override public void undo() {
        pedido.getItems().remove(producto);
        System.out.println("  [Command] UNDO - Eliminado: " + producto.getNombre());
    }
}

// 3. Invoker: ejecuta comandos y soporta undo
public class CarritoInvoker {

    private final Deque<Command> historial = new ArrayDeque<>();

    public void ejecutar(Command cmd) {
        cmd.execute();
        historial.push(cmd);  // guarda para poder deshacer
    }

    public void deshacerUltimo() {
        if (historial.isEmpty()) {
            System.out.println("  [Command] No hay acciones para deshacer");
            return;
        }
        historial.pop().undo();
    }
}

// 4. Clase de entrada para el demo
public class CommandDemo {
    public static void demo(Pedido pedido, Producto p1, Producto p2) {
        CarritoInvoker carrito = new CarritoInvoker();

        carrito.ejecutar(new AgregarAlCarrito(pedido, p1));
        carrito.ejecutar(new AgregarAlCarrito(pedido, p2));
        System.out.println("  [Command] Carrito: " + pedido);

        carrito.deshacerUltimo();  // undo
        System.out.println("  [Command] Después de undo: " + pedido);
    }
}
