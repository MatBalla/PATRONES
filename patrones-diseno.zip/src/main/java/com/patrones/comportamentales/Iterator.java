package com.patrones.comportamentales;

import com.patrones.dominio.Producto;
import java.util.List;
import java.util.NoSuchElementException;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: ITERATOR
//  ¿Cuándo? Cuando quieres recorrer una colección sin exponer
//  su representación interna (lista, árbol, mapa, etc.)
//  Java ya tiene Iterator<T>, pero implementarlo muestra
//  cómo funciona por dentro y permite iteradores personalizados.
//  Estructura:
//    - Interfaz Iterator con hasNext() y next()
//    - Iterador concreto mantiene posición interna
//    - Iterable o Collection que devuelve el iterador
// ═══════════════════════════════════════════════════════════════

// 1. Interfaz Iterator personalizado
public interface IteradorProducto {
    boolean hasNext();
    Producto next();
}

// 2. Colección que puede producir un iterador
class Catalogo {

    private final List<Producto> productos;

    public Catalogo(List<Producto> productos) {
        this.productos = productos;
    }

    // Iterador normal
    public IteradorProducto iterador() {
        return new IteradorSimple(productos);
    }

    // Iterador filtrado por categoría (sin exponer la lista interna)
    public IteradorProducto iteradorPorCategoria(String categoria) {
        return new IteradorFiltrado(productos, categoria);
    }
}

// 3. Iterador concreto simple
class IteradorSimple implements IteradorProducto {
    private final List<Producto> lista;
    private int posicion = 0;

    public IteradorSimple(List<Producto> lista) { this.lista = lista; }

    @Override public boolean hasNext() { return posicion < lista.size(); }
    @Override public Producto next() {
        if (!hasNext()) throw new NoSuchElementException();
        return lista.get(posicion++);
    }
}

// 4. Iterador concreto con filtro (lógica personalizada)
class IteradorFiltrado implements IteradorProducto {
    private final List<Producto> lista;
    private final String categoriaBuscada;
    private int posicion = 0;
    private Producto siguiente = null;

    public IteradorFiltrado(List<Producto> lista, String cat) {
        this.lista             = lista;
        this.categoriaBuscada  = cat;
        avanzar();
    }

    private void avanzar() {
        siguiente = null;
        while (posicion < lista.size()) {
            Producto p = lista.get(posicion++);
            if (p.getCategoria().equalsIgnoreCase(categoriaBuscada)) {
                siguiente = p;
                break;
            }
        }
    }

    @Override public boolean hasNext() { return siguiente != null; }

    @Override public Producto next() {
        if (!hasNext()) throw new NoSuchElementException();
        Producto resultado = siguiente;
        avanzar();
        return resultado;
    }
}

// 5. Clase de entrada para el demo
public class IteratorDemo {
    public static void demo(List<Producto> productos) {
        Catalogo catalogo = new Catalogo(productos);

        System.out.println("  [Iterator] Todos los productos:");
        IteradorProducto it = catalogo.iterador();
        while (it.hasNext()) {
            System.out.println("    → " + it.next());
        }

        System.out.println("  [Iterator] Solo electrónicos:");
        IteradorProducto filtrado = catalogo.iteradorPorCategoria("electronico");
        while (filtrado.hasNext()) {
            System.out.println("    → " + filtrado.next());
        }
    }
}
