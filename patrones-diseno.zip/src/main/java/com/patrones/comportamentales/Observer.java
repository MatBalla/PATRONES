package com.patrones.comportamentales;

import com.patrones.dominio.Pedido;
import java.util.ArrayList;
import java.util.List;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: OBSERVER
//  ¿Cuándo? Cuando un objeto (Subject) necesita notificar
//  a múltiples objetos (Observers) cuando cambia su estado,
//  sin conocerlos directamente.
//  Estructura:
//    - Interfaz Observer con método update(evento)
//    - Interfaz Subject con suscribir/desuscribir/notificar
//    - Observadores concretos reaccionan al evento
//    - Subject concreto guarda la lista y notifica
// ═══════════════════════════════════════════════════════════════

// 1. Interfaz Observer
public interface Observer {
    void actualizar(String evento, Pedido pedido);
}

// 2. Interfaz Subject
interface Subject {
    void suscribir(Observer obs);
    void desuscribir(Observer obs);
    void notificar(String evento, Pedido pedido);
}

// 3. Subject concreto: el gestor de pedidos
public class GestorPedidos implements Subject {

    private final List<Observer> observadores = new ArrayList<>();

    @Override
    public void suscribir(Observer obs)   { observadores.add(obs); }

    @Override
    public void desuscribir(Observer obs) { observadores.remove(obs); }

    @Override
    public void notificar(String evento, Pedido pedido) {
        observadores.forEach(obs -> obs.actualizar(evento, pedido));
    }

    // Método de negocio que dispara notificaciones
    public void realizarPedido(Pedido pedido) {
        System.out.println("  [Observer] Pedido registrado: " + pedido);
        notificar("PEDIDO_CREADO", pedido);
    }
}

// 4. Observadores concretos (reaccionan al evento cada uno a su manera)
class NotificadorEmail implements Observer {
    private final String email;
    public NotificadorEmail(String email) { this.email = email; }
    @Override public void actualizar(String evento, Pedido pedido) {
        System.out.printf("  [Observer→Email] Enviando a %s: %s para pedido %s%n",
                email, evento, pedido.getId());
    }
}

class AuditorLog implements Observer {
    @Override public void actualizar(String evento, Pedido pedido) {
        System.out.printf("  [Observer→Log] AUDIT: %s | pedido=%s | total=$%.2f%n",
                evento, pedido.getId(), pedido.total());
    }
}

class SistemaAnalytics implements Observer {
    @Override public void actualizar(String evento, Pedido pedido) {
        System.out.printf("  [Observer→Analytics] Evento: %s registrado%n", evento);
    }
}

// 5. Clase de entrada para el demo
public class ObserverDemo {
    public static GestorPedidos crearGestor() {
        GestorPedidos gestor = new GestorPedidos();
        gestor.suscribir(new NotificadorEmail("cliente@tienda.com"));
        gestor.suscribir(new AuditorLog());
        gestor.suscribir(new SistemaAnalytics());
        return gestor;
    }
}
