package com.patrones.comportamentales;

import com.patrones.dominio.Pedido;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: STRATEGY
//  ¿Cuándo? Cuando tienes múltiples variantes de un algoritmo
//  y quieres poder intercambiarlos en runtime.
//  Diferencia con Factory: Factory decide QUÉ objeto crear,
//  Strategy decide QUÉ algoritmo ejecutar.
//  Estructura:
//    - Interfaz Strategy con el método del algoritmo
//    - Clases concretas: una por variante del algoritmo
//    - Contexto: tiene una Strategy y la ejecuta
// ═══════════════════════════════════════════════════════════════

// 1. Interfaz Strategy
public interface DescuentoStrategy {
    double aplicar(double totalOriginal);
    String getNombre();
}

// 2. Estrategias concretas (algoritmos intercambiables)
class SinDescuento implements DescuentoStrategy {
    @Override public double aplicar(double total) { return total; }
    @Override public String getNombre()           { return "Sin descuento"; }
}

class DescuentoPorcentaje implements DescuentoStrategy {
    private final double pct;
    public DescuentoPorcentaje(double pct) { this.pct = pct; }
    @Override public double aplicar(double total) { return total * (1 - pct / 100.0); }
    @Override public String getNombre() { return pct + "% de descuento"; }
}

class DescuentoFijo implements DescuentoStrategy {
    private final double monto;
    public DescuentoFijo(double monto) { this.monto = monto; }
    @Override public double aplicar(double total) { return Math.max(0, total - monto); }
    @Override public String getNombre() { return "$" + monto + " de descuento fijo"; }
}

// 3. Contexto: usa la estrategia sin conocer cuál es
public class CalculadoraPrecio {

    private DescuentoStrategy estrategia;

    public CalculadoraPrecio(DescuentoStrategy estrategia) {
        this.estrategia = estrategia;
    }

    // Cambiar estrategia en runtime
    public void setEstrategia(DescuentoStrategy e) { this.estrategia = e; }

    public void calcular(Pedido pedido) {
        double original   = pedido.total();
        double conDescto  = estrategia.aplicar(original);
        System.out.printf("  [Strategy] %s → original: $%.2f → final: $%.2f%n",
                estrategia.getNombre(), original, conDescto);
    }
}

// 4. Clase de entrada para el demo
public class Strategy {
    public static DescuentoStrategy sinDescuento()              { return new SinDescuento(); }
    public static DescuentoStrategy porcentaje(double pct)      { return new DescuentoPorcentaje(pct); }
    public static DescuentoStrategy fijo(double monto)          { return new DescuentoFijo(monto); }
    public static CalculadoraPrecio calculadora(DescuentoStrategy e) { return new CalculadoraPrecio(e); }
}
