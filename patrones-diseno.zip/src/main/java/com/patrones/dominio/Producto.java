package com.patrones.dominio;

// ─────────────────────────────────────────────────────────────
//  DOMINIO BASE
//  Todo el sistema gira en torno a Producto y Pedido.
//  Los patrones lo crean, decoran, adaptan y controlan.
// ─────────────────────────────────────────────────────────────

public class Producto {

    private final String nombre;
    private final double precio;
    private final String categoria;

    public Producto(String nombre, double precio, String categoria) {
        this.nombre    = nombre;
        this.precio    = precio;
        this.categoria = categoria;
    }

    public String getNombre()    { return nombre;    }
    public double getPrecio()    { return precio;    }
    public String getCategoria() { return categoria; }

    @Override
    public String toString() {
        return String.format("Producto{nombre='%s', precio=%.2f, cat='%s'}",
                nombre, precio, categoria);
    }
}
