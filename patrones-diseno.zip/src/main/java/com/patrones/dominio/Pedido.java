package com.patrones.dominio;

import java.util.ArrayList;
import java.util.List;

public class Pedido {

    private final String id;
    private final List<Producto> items = new ArrayList<>();

    public Pedido(String id) { this.id = id; }

    public void agregar(Producto p)    { items.add(p); }
    public List<Producto> getItems()   { return items; }
    public String getId()              { return id;    }

    public double total() {
        return items.stream().mapToDouble(Producto::getPrecio).sum();
    }

    @Override
    public String toString() {
        return String.format("Pedido[%s] — %d items — total: $%.2f", id, items.size(), total());
    }
}
