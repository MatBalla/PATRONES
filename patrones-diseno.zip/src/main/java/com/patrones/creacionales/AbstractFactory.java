package com.patrones.creacionales;

import com.patrones.dominio.Producto;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: ABSTRACT FACTORY
//  ¿Cuándo? Cuando necesitas crear FAMILIAS de objetos
//  relacionados sin acoplar el código a clases concretas.
//  Diferencia con Factory Method: crea múltiples tipos
//  relacionados, no solo uno.
//  Estructura:
//    - Interfaz fábrica abstracta con varios métodos crear*()
//    - Implementaciones concretas de la fábrica (una por familia)
//    - Interfaces para cada producto de la familia
//    - El cliente solo conoce las interfaces
// ═══════════════════════════════════════════════════════════════

// 1. Interfaces de los productos de la familia
interface Boton      { void renderizar(); }
interface Formulario { void mostrar(); }

// 2. Familia "Oscura"
class BotonOscuro implements Boton {
    @Override public void renderizar() { System.out.println("  [AbsFact] 🔲 Botón oscuro"); }
}
class FormularioOscuro implements Formulario {
    @Override public void mostrar() { System.out.println("  [AbsFact] 📋 Formulario oscuro"); }
}

// 3. Familia "Clara"
class BotonClaro implements Boton {
    @Override public void renderizar() { System.out.println("  [AbsFact] ⬜ Botón claro"); }
}
class FormularioClaro implements Formulario {
    @Override public void mostrar() { System.out.println("  [AbsFact] 📄 Formulario claro"); }
}

// 4. Interfaz de la fábrica abstracta
public interface FabricaUI {
    Boton      crearBoton();
    Formulario crearFormulario();
}

// 5. Fábricas concretas (una por familia)
class FabricaOscura implements FabricaUI {
    @Override public Boton      crearBoton()      { return new BotonOscuro(); }
    @Override public Formulario crearFormulario() { return new FormularioOscuro(); }
}
class FabricaClara implements FabricaUI {
    @Override public Boton      crearBoton()      { return new BotonClaro(); }
    @Override public Formulario crearFormulario() { return new FormularioClaro(); }
}

// 6. Clase de entrada para el demo
public class AbstractFactory {

    // El cliente recibe la fábrica, nunca instancia los productos directamente
    public static void renderizarUI(FabricaUI fabrica) {
        Boton      boton      = fabrica.crearBoton();
        Formulario formulario = fabrica.crearFormulario();
        boton.renderizar();
        formulario.mostrar();
    }

    public static FabricaUI obtenerFabrica(String tema) {
        return tema.equals("oscuro") ? new FabricaOscura() : new FabricaClara();
    }
}
