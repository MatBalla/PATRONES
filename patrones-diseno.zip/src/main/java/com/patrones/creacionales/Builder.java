package com.patrones.creacionales;

import com.patrones.dominio.Pedido;
import com.patrones.dominio.Producto;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: BUILDER
//  ¿Cuándo? Cuando un objeto se construye en muchos pasos
//  y quieres controlar exactamente qué pasos se ejecutan.
//  Diferencia con Factory: Factory crea en un paso, Builder
//  construye paso a paso con estado intermedio.
//  Estructura:
//    - Clase Builder con métodos encadenables (fluent API)
//    - Cada método configura una parte del objeto
//    - build() devuelve el objeto terminado
// ═══════════════════════════════════════════════════════════════

public class PedidoBuilder {

    // Estado intermedio del objeto en construcción
    private final Pedido pedido;
    private String codigoDescuento = null;
    private boolean envioExpress   = false;

    // Crear un Builder para un pedido con ID
    public PedidoBuilder(String id) {
        this.pedido = new Pedido(id);
        System.out.println("  [Builder] Iniciando pedido " + id);
    }

    // Cada método devuelve this para encadenar
    public PedidoBuilder agregarProducto(Producto p) {
        pedido.agregar(p);
        System.out.println("  [Builder] + " + p.getNombre());
        return this;
    }

    public PedidoBuilder conDescuento(String codigo) {
        this.codigoDescuento = codigo;
        System.out.println("  [Builder] Descuento aplicado: " + codigo);
        return this;
    }

    public PedidoBuilder envioExpress() {
        this.envioExpress = true;
        System.out.println("  [Builder] Envío express activado");
        return this;
    }

    // Paso final: devuelve el objeto completamente construido
    public Pedido build() {
        System.out.println("  [Builder] Pedido listo → " + pedido);
        return pedido;
    }
}
