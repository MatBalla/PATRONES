package com.patrones.creacionales;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: SINGLETON
//  ¿Cuándo? Cuando solo puede existir UNA instancia global.
//  Estructura:
//    - Constructor privado
//    - Campo estático privado con la instancia
//    - Método estático getInstance() que la crea o devuelve
// ═══════════════════════════════════════════════════════════════

public class ConfiguracionTienda {

    // 1. Campo estático privado (la única instancia)
    private static ConfiguracionTienda instancia;

    // 2. Estado interno de la configuración
    private String moneda  = "USD";
    private double iva     = 0.12;
    private String idioma  = "es";

    // 3. Constructor privado: nadie puede hacer new ConfiguracionTienda()
    private ConfiguracionTienda() {
        System.out.println("  [Singleton] Configuración creada (solo ocurre una vez)");
    }

    // 4. Punto de acceso global
    public static ConfiguracionTienda getInstance() {
        if (instancia == null) {
            instancia = new ConfiguracionTienda();
        }
        return instancia;
    }

    // 5. API normal de la clase
    public String getMoneda()        { return moneda; }
    public double getIva()           { return iva;    }
    public String getIdioma()        { return idioma; }
    public void setMoneda(String m)  { this.moneda = m; }

    @Override
    public String toString() {
        return String.format("Config{moneda=%s, iva=%.0f%%, idioma=%s}", moneda, iva*100, idioma);
    }
}
