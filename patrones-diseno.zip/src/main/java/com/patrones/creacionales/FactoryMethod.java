package com.patrones.creacionales;

import com.patrones.dominio.Producto;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: FACTORY METHOD
//  ¿Cuándo? Cuando el código base sabe QUÉ crear pero las
//  subclases deciden CÓMO crearlo.
//  Estructura:
//    - Clase abstracta con método abstracto crearProducto()
//    - Subclases concretas implementan la creación
//    - El código cliente llama al abstracto, no al concreto
// ═══════════════════════════════════════════════════════════════

// 1. Creador abstracto (define el contrato)
public abstract class CreadorProducto {

    // El "factory method" — subclases lo implementan
    public abstract Producto crearProducto(String nombre, double precio);

    // Lógica de negocio que usa el factory method
    public void mostrarProducto(String nombre, double precio) {
        Producto p = crearProducto(nombre, precio);   // polimorfismo en acción
        System.out.println("  [FactoryMethod] Creado: " + p);
    }
}

// 2. Creador concreto para electrónicos
public class CreadorElectronico extends CreadorProducto {
    @Override
    public Producto crearProducto(String nombre, double precio) {
        return new Producto(nombre, precio * 1.15, "Electrónico"); // precio con impuesto especial
    }
}

// 3. Creador concreto para alimentos
class CreadorAlimento extends CreadorProducto {
    @Override
    public Producto crearProducto(String nombre, double precio) {
        return new Producto(nombre, precio, "Alimento");
    }
}

// 4. Clase pública de entrada para el demo
public class FactoryMethod {

    public static CreadorProducto obtenerCreador(String tipo) {
        return switch (tipo.toLowerCase()) {
            case "electronico" -> new CreadorElectronico();
            case "alimento"    -> new CreadorAlimento();
            default -> throw new IllegalArgumentException("Tipo desconocido: " + tipo);
        };
    }
}
