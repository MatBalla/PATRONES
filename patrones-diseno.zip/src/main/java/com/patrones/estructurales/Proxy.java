package com.patrones.estructurales;

import com.patrones.dominio.Producto;
import java.util.HashMap;
import java.util.Map;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: PROXY
//  ¿Cuándo? Cuando quieres controlar el acceso a un objeto:
//  añadir caché, logging, control de permisos, lazy loading.
//  El cliente no sabe si habla con el real o el proxy.
//  Diferencia con Decorator: Proxy controla acceso,
//  Decorator añade comportamiento al objeto en sí.
//  Estructura:
//    - Interfaz compartida (Subject)
//    - Objeto real (RealSubject)
//    - Proxy implementa la misma interfaz y controla el acceso
// ═══════════════════════════════════════════════════════════════

// 1. Interfaz compartida entre real y proxy
interface CatalogoService {
    Producto buscar(String nombre);
}

// 2. Servicio real (puede ser lento, costoso)
class CatalogoReal implements CatalogoService {
    @Override
    public Producto buscar(String nombre) {
        System.out.println("  [Proxy→Real] Buscando en base de datos: " + nombre);
        // Simula consulta lenta a BD
        return new Producto(nombre, 99.99, "general");
    }
}

// 3. Proxy con caché: intercepta y memoriza resultados
public class CatalogoProxy implements CatalogoService {

    private final CatalogoReal real  = new CatalogoReal();       // objeto real
    private final Map<String, Producto> cache = new HashMap<>();  // caché

    @Override
    public Producto buscar(String nombre) {
        if (cache.containsKey(nombre)) {
            System.out.println("  [Proxy] CACHE HIT: " + nombre);
            return cache.get(nombre);
        }
        // No está en caché: delega al real y guarda resultado
        Producto p = real.buscar(nombre);
        cache.put(nombre, p);
        return p;
    }

    public static void demo() {
        CatalogoService catalogo = new CatalogoProxy();  // cliente usa la interfaz, no sabe si es proxy
        catalogo.buscar("Auriculares");   // va a BD
        catalogo.buscar("Auriculares");   // viene del caché
        catalogo.buscar("Teclado");       // va a BD
    }
}
