package com.patrones.estructurales;

import com.patrones.dominio.Producto;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: DECORATOR
//  ¿Cuándo? Cuando quieres añadir responsabilidades a un objeto
//  dinámicamente, en runtime, sin usar herencia.
//  Diferencia con herencia: puedes combinar N decoradores
//  libremente; con herencia necesitarías subclase por combinación.
//  Estructura:
//    - Interfaz o clase base (Component)
//    - Decorator abstracto: implementa la interfaz y CONTIENE uno
//    - Decoradores concretos añaden comportamiento extra
// ═══════════════════════════════════════════════════════════════

// 1. Interfaz base que decoradores y producto comparten
interface Mostrable {
    String describir();
    double getPrecio();
}

// 2. Componente concreto (el objeto original envuelto)
class ProductoMostrable implements Mostrable {
    private final Producto producto;
    public ProductoMostrable(Producto p) { this.producto = p; }
    @Override public String describir()  { return producto.getNombre(); }
    @Override public double getPrecio()  { return producto.getPrecio(); }
}

// 3. Decorator abstracto: contiene un Mostrable (delegación)
abstract class ProductoDecorator implements Mostrable {
    protected final Mostrable envuelto;
    public ProductoDecorator(Mostrable m) { this.envuelto = m; }
    @Override public double getPrecio()  { return envuelto.getPrecio(); }  // delega por defecto
}

// 4. Decorator concreto: añade etiqueta de descuento
class ConDescuento extends ProductoDecorator {
    private final double porcentaje;
    public ConDescuento(Mostrable m, double pct) {
        super(m);
        this.porcentaje = pct;
    }
    @Override public String describir() {
        return envuelto.describir() + " [" + (int)porcentaje + "% OFF]";
    }
    @Override public double getPrecio() {
        return envuelto.getPrecio() * (1 - porcentaje / 100.0);
    }
}

// 5. Decorator concreto: añade etiqueta "destacado"
class Destacado extends ProductoDecorator {
    public Destacado(Mostrable m) { super(m); }
    @Override public String describir() {
        return "★ " + envuelto.describir();
    }
}

// 6. Clase de entrada para el demo
public class Decorator {

    public static void demo(Producto productoBase) {
        // Envuelves el producto original
        Mostrable base = new ProductoMostrable(productoBase);

        // Combinas decoradores libremente en runtime
        Mostrable conDescuento  = new ConDescuento(base, 20);
        Mostrable destacado     = new Destacado(conDescuento);

        System.out.printf("  [Decorator] Base:      %-30s $%.2f%n",
                base.describir(), base.getPrecio());
        System.out.printf("  [Decorator] Decorado:  %-30s $%.2f%n",
                destacado.describir(), destacado.getPrecio());
    }
}
