package com.patrones.estructurales;

import com.patrones.dominio.Pedido;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: FACADE
//  ¿Cuándo? Cuando tienes un subsistema complejo con muchas
//  clases y quieres exponer una interfaz simple.
//  No oculta las clases internas, solo provee un acceso simple.
//  Estructura:
//    - Múltiples subsistemas con lógica propia
//    - Clase Facade que los coordina en métodos simples
//    - El cliente llama solo a la Facade
// ═══════════════════════════════════════════════════════════════

// 1. Subsistemas internos (complejos, con mucha lógica propia)
class ServicioInventario {
    public boolean verificarStock(Pedido p) {
        System.out.println("  [Facade→Inventario] Verificando stock de " + p.getItems().size() + " items...");
        return true;  // simplificado
    }
}

class ServicioPago {
    public boolean procesarPago(Pedido p, String tarjeta) {
        System.out.printf("  [Facade→Pago] Procesando $%.2f con tarjeta %s...%n",
                p.total(), tarjeta.substring(tarjeta.length() - 4));
        return true;
    }
}

class ServicioEnvio {
    public String programarEnvio(Pedido p, String direccion) {
        String trackingId = "TRK-" + p.getId() + "-001";
        System.out.println("  [Facade→Envío] Envío a: " + direccion + " | Tracking: " + trackingId);
        return trackingId;
    }
}

class ServicioNotificacion {
    public void notificarCliente(String email, String trackingId) {
        System.out.println("  [Facade→Email] Confirmación enviada a " + email + " | " + trackingId);
    }
}

// 2. Facade: interfaz unificada para el proceso de checkout
public class CheckoutFacade {

    // Coordina todos los subsistemas
    private final ServicioInventario  inventario    = new ServicioInventario();
    private final ServicioPago        pago          = new ServicioPago();
    private final ServicioEnvio       envio         = new ServicioEnvio();
    private final ServicioNotificacion notificacion = new ServicioNotificacion();

    // Un solo método para el cliente — oculta la complejidad
    public boolean completarCompra(Pedido pedido, String tarjeta,
                                   String direccion, String email) {
        System.out.println("  [Facade] Iniciando checkout de " + pedido);

        if (!inventario.verificarStock(pedido)) return false;
        if (!pago.procesarPago(pedido, tarjeta)) return false;

        String tracking = envio.programarEnvio(pedido, direccion);
        notificacion.notificarCliente(email, tracking);

        System.out.println("  [Facade] ✓ Compra completada");
        return true;
    }
}
