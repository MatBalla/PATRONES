package com.patrones.estructurales;

import com.patrones.dominio.Producto;
import java.util.ArrayList;
import java.util.List;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: COMPOSITE
//  ¿Cuándo? Cuando tienes una jerarquía árbol y quieres
//  tratar igual a nodos individuales y a grupos.
//  Ejemplo: un archivo y una carpeta (que contiene archivos)
//  se tratan igual con el método mostrar().
//  Estructura:
//    - Interfaz Component (lo que hojas y compuestos comparten)
//    - Leaf: nodo hoja (sin hijos)
//    - Composite: nodo rama (contiene otros Component)
// ═══════════════════════════════════════════════════════════════

// 1. Interfaz Component
interface ItemCatalogo {
    void mostrar(String prefijo);
    double getPrecioTotal();
}

// 2. Leaf (hoja): un producto individual
class ItemProducto implements ItemCatalogo {
    private final Producto producto;
    public ItemProducto(Producto p) { this.producto = p; }

    @Override
    public void mostrar(String prefijo) {
        System.out.printf("%s📦 %-25s $%.2f%n",
                prefijo, producto.getNombre(), producto.getPrecio());
    }
    @Override public double getPrecioTotal() { return producto.getPrecio(); }
}

// 3. Composite (rama): una categoría que contiene items
class Categoria implements ItemCatalogo {
    private final String nombre;
    private final List<ItemCatalogo> hijos = new ArrayList<>();

    public Categoria(String nombre) { this.nombre = nombre; }

    public Categoria agregar(ItemCatalogo item) { hijos.add(item); return this; }

    @Override
    public void mostrar(String prefijo) {
        System.out.println(prefijo + "📁 " + nombre);
        hijos.forEach(h -> h.mostrar(prefijo + "   "));  // recursivo
    }

    @Override
    public double getPrecioTotal() {
        return hijos.stream().mapToDouble(ItemCatalogo::getPrecioTotal).sum();
    }
}

// 4. Clase de entrada para el demo
public class Composite {

    public static void demo() {
        // Construir árbol
        Categoria electronica = new Categoria("Electrónica")
            .agregar(new ItemProducto(new Producto("Laptop", 1200, "e")))
            .agregar(new ItemProducto(new Producto("Mouse",    25, "e")));

        Categoria audio = new Categoria("Audio")
            .agregar(new ItemProducto(new Producto("Auriculares", 80, "a")))
            .agregar(new ItemProducto(new Producto("Parlante",   150, "a")));

        Categoria tienda = new Categoria("Toda la tienda")
            .agregar(electronica)
            .agregar(audio);

        // Se llama igual en hoja y en grupo
        tienda.mostrar("");
        System.out.printf("  [Composite] Total catálogo: $%.2f%n", tienda.getPrecioTotal());
    }
}
