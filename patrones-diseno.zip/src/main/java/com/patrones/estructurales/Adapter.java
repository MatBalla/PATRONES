package com.patrones.estructurales;

import com.patrones.dominio.Producto;

// ═══════════════════════════════════════════════════════════════
//  PATRÓN: ADAPTER
//  ¿Cuándo? Cuando tienes una clase existente con interfaz
//  incompatible y necesitas que funcione con tu sistema
//  sin modificar ninguna de las dos.
//  Estructura:
//    - Interfaz que tu sistema espera (Target)
//    - Clase externa con interfaz diferente (Adaptee)
//    - Adapter implementa Target y envuelve al Adaptee
// ═══════════════════════════════════════════════════════════════

// 1. Interfaz que nuestro sistema espera
interface RepositorioProducto {
    Producto buscarPorId(String id);
}

// 2. Clase externa incompatible (no podemos modificarla)
class ProveedorExternoAPI {
    // Devuelve formato diferente: un mapa de strings
    public String[] obtenerItem(int codigo) {
        // Simula respuesta externa: [nombre, precio, tipo]
        return new String[]{"Laptop Pro " + codigo, "1200.00", "electronico"};
    }
}

// 3. Adapter: implementa la interfaz del sistema y delega al externo
class ProveedorExternoAdapter implements RepositorioProducto {

    private final ProveedorExternoAPI api;  // envuelve al adaptee

    public ProveedorExternoAdapter(ProveedorExternoAPI api) {
        this.api = api;
    }

    @Override
    public Producto buscarPorId(String id) {
        // Convierte el id a int y llama la API externa
        String[] data = api.obtenerItem(Integer.parseInt(id));
        // Traduce el formato externo al formato interno
        return new Producto(data[0], Double.parseDouble(data[1]), data[2]);
    }
}

// 4. Clase de entrada para el demo
public class Adapter {

    public static RepositorioProducto crearRepositorioExterno() {
        ProveedorExternoAPI api = new ProveedorExternoAPI();
        return new ProveedorExternoAdapter(api);
    }

    public static void demo() {
        RepositorioProducto repo = crearRepositorioExterno();
        Producto p = repo.buscarPorId("42");  // código cliente ignora el adaptee
        System.out.println("  [Adapter] Producto obtenido: " + p);
    }
}
