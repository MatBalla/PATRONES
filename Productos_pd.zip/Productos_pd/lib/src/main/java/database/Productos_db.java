package database;

import com.modelo.*;
import factory.FactoryGen;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Productos_db {

    public boolean esConexionValida() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            return conn != null && conn.isValid(1);
        } catch (SQLException e) {
            return false;
        }
    }
    
    public void insertar(Productos p) {
        String sql = "INSERT INTO productos (lote, caducidad, tipo, pais, temperatura, info_extra) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, p.getNum_lote());
            pstmt.setString(2, p.getFecha_cad());

            // Lógica para productos específicos
            if (p instanceof ProductosFrescos) {
                pstmt.setString(3, "PRODUCTO_FRESCO");
                pstmt.setString(4, ((ProductosFrescos) p).getPais_Origen());
                pstmt.setString(6, "Env: " + ((ProductosFrescos) p).getFecha_Env());
            } 
            else if (p instanceof ProductosRefrigerados) {
                pstmt.setString(3, "PRODUCTO_REFRIGERADO");
                pstmt.setString(4, ((ProductosRefrigerados) p).getPais_Origen());
                pstmt.setDouble(5, ((ProductosRefrigerados) p).getTemperatura());
                pstmt.setString(6, "Cod: " + ((ProductosRefrigerados) p).getCodigo_Org());
            }
            // PRODUCTOS CONGELADOS
            else if (p instanceof Prod_CongeladosAgua) {
                pstmt.setString(3, "PRODUCTO_CONGELADO_AGUA");
                pstmt.setString(4, ((Prod_CongeladosAgua) p).getPais_Origen());
                pstmt.setDouble(5, ((Prod_CongeladosAgua) p).getTemperatura());
                pstmt.setString(6, "Salinidad: " + ((Prod_CongeladosAgua) p).getSalinidad());
            }
            else if (p instanceof Prod_CongeladosAire) {
                Prod_CongeladosAire aire = (Prod_CongeladosAire) p;
                pstmt.setString(3, "PRODUCTO_CONGELADO_AIRE");
                pstmt.setString(4, aire.getPais_Origen());
                pstmt.setDouble(5, aire.getTemperatura());
                // Guardamos la composición del aire como un texto
                pstmt.setString(6, String.format("N2:%.1f|O2:%.1f|CO2:%.1f|H2O:%.1f", 
                    aire.getNitrogeno(), aire.getOxigeno(), aire.getDioxidoC(), aire.getVaporAgua()));
            }
            else if (p instanceof Prod_CongeladosNitrogeno) {
                Prod_CongeladosNitrogeno nit = (Prod_CongeladosNitrogeno) p;
                pstmt.setString(3, "PRODUCTO_CONGELADO_NITROGENO");
                pstmt.setString(4, nit.getPais_Origen());
                pstmt.setDouble(5, nit.getTemperatura());
                pstmt.setString(6, "Metodo: " + nit.getMetodo_congelacion_empl() + " | Tiempo: " + nit.getTiempo_exp_nitrogeno());
            }

            pstmt.executeUpdate();
            System.out.println("✅ Guardado exitoso: " + p.getClass().getSimpleName());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Productos> listarTodos() {
        List<Productos> lista = new ArrayList<>();
        String sql = "SELECT * FROM productos";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String tipo = rs.getString("tipo");
                String cad = rs.getString("caducidad");
                String lote = rs.getString("lote");

                // 1. La factory crea la instancia básica (gracias al constructor corto)
                Productos p = new FactoryGen().crear(tipo, cad, lote);
                
                if (p != null) {
                    // 2. Rellenamos los datos comunes que guardamos en 'pais'
                    String pais = rs.getString("pais");
                    String infoExtra = rs.getString("info_extra");
                    double temp = rs.getDouble("temperatura");

                    // 3. Casteo inteligente para usar los Setters específicos
                    if (p instanceof ProductosFrescos) {
                        ProductosFrescos f = (ProductosFrescos) p;
                        f.setPais_Origen(pais);
                        f.setFecha_Env(infoExtra); // Recuperamos la fecha de envasado
                    } 
                    else if (p instanceof ProductosRefrigerados) {
                        ProductosRefrigerados r = (ProductosRefrigerados) p;
                        r.setPais_Origen(pais);
                        r.setTemperatura(temp);
                        r.setCodigo_Org(infoExtra);
                    }
                    else if (p instanceof ProductosCongelados) {
                        ProductosCongelados c = (ProductosCongelados) p;
                        c.setPais_Origen(pais);
                        c.setTemperatura(temp);
                        c.setFecha_Env(infoExtra);
                    }
                    
                    lista.add(p);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
    
    
    
    public void actualizar(Productos p) {
        // Usamos el lote para saber cuál fila cambiar
        String sql = "UPDATE productos SET caducidad = ?, pais = ?, temperatura = ? WHERE lote = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, p.getFecha_cad());
            
            // Manejo de datos específicos para el update
            if (p instanceof ProductosFrescos) {
                pstmt.setString(2, ((ProductosFrescos) p).getPais_Origen());
                pstmt.setNull(3, Types.DOUBLE);
            } else if (p instanceof ProductosRefrigerados) {
                pstmt.setString(2, ((ProductosRefrigerados) p).getPais_Origen());
                pstmt.setDouble(3, ((ProductosRefrigerados) p).getTemperatura());
            }
            
            pstmt.setInt(4, p.getNum_lote()); // El WHERE lote = ?

            int filasAfectadas = pstmt.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("✅ Producto " + p.getNum_lote() + " actualizado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    public void eliminar(int lote) {
        String sql = "DELETE FROM productos WHERE lote = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, lote);
            
            int filasAfectadas = pstmt.executeUpdate();
            if (filasAfectadas > 0) {
                System.out.println("🗑️ Producto con lote " + lote + " eliminado de la base de datos.");
            } else {
                System.out.println("⚠️ No se encontró ningún producto con el lote " + lote);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}