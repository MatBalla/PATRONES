package database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {

    private static HikariDataSource dataSource;

    static {
        // 1. Configuración básica
        HikariConfig config = new HikariConfig();
        
        // Crea el archivo productos_agricolas.db en la carpeta del proyecto
        config.setJdbcUrl("jdbc:sqlite:productos.db");
        
        // 2. Parámetros mínimos del pool
        config.setMaximumPoolSize(5); // Suficiente para un proyecto de clase
        config.setConnectionTimeout(30000); 

        dataSource = new HikariDataSource(config);
    }

    // 3. Método que usa tu CRUD
    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }
    
    public static void crearTablaSiNoExiste() {
        String sql = "CREATE TABLE IF NOT EXISTS productos (" +
                     "lote INTEGER PRIMARY KEY, " +
                     "caducidad TEXT, " +
                     "tipo TEXT, " +
                     "pais TEXT, " +
                     "temperatura REAL, " +
                     "info_extra TEXT);";
                     
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("✅ Tabla 'productos' verificada/creada.");
        } catch (SQLException e) {
            System.err.println("❌ Error al crear la tabla: " + e.getMessage());
        }
    }
}
