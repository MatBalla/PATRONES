package factory;

import java.util.HashMap;
import anotacion.*;
import java.util.Map;
import com.google.common.reflect.ClassPath;

public class FactoryGen implements Factory {
    
    // DEBE SER STATIC para que persista entre llamadas
    private static Map<String, Class> componentes = new HashMap<String, Class>();

    @Override
    public void init(String pkgName) {
        try {
            ClassPath classPath = ClassPath.from(FactoryGen.class.getClassLoader());
            var clases = classPath.getTopLevelClassesRecursive(pkgName);
            
            for(var it: clases) {
                var miProd = it.load().getAnnotation(MiComponente.class);
                if(miProd != null) {
                    // Guardamos en el mapa estático
                    componentes.put(miProd.name(), it.load());
                    System.out.println("Registrado: " + miProd.name()); // Para que veas que sí carga
                }
            }
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
    }

    public <T> T crear(String name, String fecha_cad, String num_lote) {
        var value = componentes.get(name);
        if(value == null) {
            // Este es el error que te salió
            throw new RuntimeException("Producto " + name + " no está registrado. " +
                                       "¿Llamaste a factory.init() en el Main?");
        }
        try {
            int loteInt = Integer.parseInt(num_lote);
            var cto = value.getConstructor(String.class, int.class);
            return (T) cto.newInstance(fecha_cad, loteInt);
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
    }
}