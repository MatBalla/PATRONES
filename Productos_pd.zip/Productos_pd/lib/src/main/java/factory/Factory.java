package factory;

public interface Factory {
	
	void init(String pkgName);
	<T>T crear (String name, String fecha_cad, String num_lote);

}
