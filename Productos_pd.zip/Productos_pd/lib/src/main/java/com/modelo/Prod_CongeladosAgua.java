package com.modelo;

import anotacion.MiComponente;

@MiComponente(name = "PRODUCTO_CONGELADO_AGUA")
public class Prod_CongeladosAgua extends ProductosCongelados{
	private double salinidad;

	public Prod_CongeladosAgua(String fecha_cad, int num_lote) {
	    super(fecha_cad, num_lote);
	}
	
	public Prod_CongeladosAgua(String fecha_cad, int num_lote, String fecha_Env, String pais_Origen, 
			double temperatura, double salinidad) {
		super(fecha_cad, num_lote, fecha_Env, pais_Origen, temperatura);
		this.salinidad = salinidad;
	}



	public double getSalinidad() {
		return salinidad;
	}

	public void setSalinidad(double salinidad) {
		this.salinidad = salinidad;
	}

	@Override
	public String toString() {
		return "Prod_CongeladosAgua [salinidad=" + salinidad + "]";
	}

	
}
