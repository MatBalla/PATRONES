package com.modelo;

public class Productos {
	
	private String fecha_cad;
	private int num_lote;
	
	
	public Productos(String fecha_cad, int num_lote) {
		super();
		this.fecha_cad = fecha_cad;
		this.num_lote = num_lote;
	}
	public String getFecha_cad() {
		return fecha_cad;
	}
	public void setFecha_cad(String fecha_cad) {
		this.fecha_cad = fecha_cad;
	}
	public int getNum_lote() {
		return num_lote;
	}
	public void setNum_lote(int num_lote) {
		this.num_lote = num_lote;
	}
	@Override
	public String toString() {
		return "Productos [fecha_cad=" + fecha_cad + ", num_lote=" + num_lote + "]";
	}
	
	
	
	
	
	
	
	
	
	

}
