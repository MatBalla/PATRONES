package com.modelo;

import anotacion.MiComponente;

@MiComponente(name = "PRODUCTO_CONGELADO_AIRE")
public class Prod_CongeladosAire extends ProductosCongelados{
	private double nitrogeno;
	private double oxigeno;
	private double dioxidoC;
	private double vaporAgua;

	public Prod_CongeladosAire(String fecha_cad, int num_lote) {
	    super(fecha_cad, num_lote);
	}
	
	public Prod_CongeladosAire(String fecha_cad, int num_lote, String fecha_Env, String pais_Origen, 
			double temperatura, double nitrogeno, double oxigeno, 
			double dioxidoC, double vaporAgua) {
		super(fecha_cad, num_lote, fecha_Env, pais_Origen, temperatura);
		this.nitrogeno = nitrogeno;
		this.oxigeno = oxigeno;
		this.dioxidoC = dioxidoC;
		this.vaporAgua = vaporAgua;
	}

	public double getNitrogeno() {
		return nitrogeno;
	}

	public void setNitrogeno(double nitrogeno) {
		this.nitrogeno = nitrogeno;
	}

	public double getOxigeno() {
		return oxigeno;
	}

	public void setOxigeno(double oxigeno) {
		this.oxigeno = oxigeno;
	}

	public double getDioxidoC() {
		return dioxidoC;
	}

	public void setDioxidoC(double dioxidoC) {
		this.dioxidoC = dioxidoC;
	}

	public double getVaporAgua() {
		return vaporAgua;
	}

	public void setVaporAgua(double vaporAgua) {
		this.vaporAgua = vaporAgua;
	}

	@Override
	public String toString() {
		return "Prod_CongeladosAire [nitrogeno=" + nitrogeno + ", oxigeno=" + oxigeno + ", dioxidoC=" + dioxidoC
				+ ", vaporAgua=" + vaporAgua + "]";
	}
	
	

}
