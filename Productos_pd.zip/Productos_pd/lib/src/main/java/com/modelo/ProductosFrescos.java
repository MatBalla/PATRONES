package com.modelo;
import anotacion.MiComponente;

@MiComponente(name = "PRODUCTO_FRESCO")
public class ProductosFrescos extends Productos{
	private String fecha_Env;
	private String pais_Origen;
	
	public ProductosFrescos(String fecha_cad, int num_lote, String fecha_Env, String pais_Origen) {
		super(fecha_cad, num_lote);
		this.fecha_Env = fecha_Env;
		this.pais_Origen = pais_Origen;
	}
	public ProductosFrescos(String fecha_cad, int num_lote) {
	    super(fecha_cad, num_lote);
	}

	public String getFecha_Env() {
		return fecha_Env;
	}

	public void setFecha_Env(String fecha_Env) {
		this.fecha_Env = fecha_Env;
	}

	public String getPais_Origen() {
		return pais_Origen;
	}

	public void setPais_Origen(String pais_Origen) {
		this.pais_Origen = pais_Origen;
	}

	@Override
	public String toString() {
		return "ProductosFrescos [fecha_Env=" + fecha_Env + ", pais_Origen=" + pais_Origen + "]";
	}
	
	
	
	
	
	
	
	

	

	

	

	
	

}
