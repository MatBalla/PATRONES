package com.modelo;
import anotacion.MiComponente;

@MiComponente(name = "PRODUCTO_REFRIGERADO")
public class ProductosRefrigerados extends Productos{
	private String codigo_Org;
	private String fecha_Env;
	private double temperatura;
	private String pais_Origen;

	public ProductosRefrigerados(String fecha_cad, int num_lote, 
			String codigo_Org, String fecha_Env, double temperatura, String pais_Origen) {
		super(fecha_cad, num_lote);
		this.codigo_Org = codigo_Org;
		this.fecha_Env = fecha_Env;
		this.temperatura = temperatura;
		this.pais_Origen = pais_Origen;
	}
	
	public ProductosRefrigerados(String fecha_cad, int num_lote) {
	    super(fecha_cad, num_lote);
	}

	public String getCodigo_Org() {
		return codigo_Org;
	}

	public void setCodigo_Org(String codigo_Org) {
		this.codigo_Org = codigo_Org;
	}

	public String getFecha_Env() {
		return fecha_Env;
	}

	public void setFecha_Env(String fecha_Env) {
		this.fecha_Env = fecha_Env;
	}

	public double getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(double temperatura) {
		this.temperatura = temperatura;
	}

	public String getPais_Origen() {
		return pais_Origen;
	}

	public void setPais_Origen(String pais_Origen) {
		this.pais_Origen = pais_Origen;
	}

	@Override
	public String toString() {
		return "ProductosRefrigerados [codigo_Org=" + codigo_Org + ", fecha_Env=" + fecha_Env + ", temperatura="
				+ temperatura + ", pais_Origen=" + pais_Origen + "]";
	}
	
	
	
	
	

	

	
	
	
	
	

}
