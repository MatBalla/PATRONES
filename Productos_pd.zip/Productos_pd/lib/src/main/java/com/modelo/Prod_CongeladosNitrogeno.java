package com.modelo;

import anotacion.MiComponente;

@MiComponente(name = "PRODUCTO_CONGELADO_NITROGENO")
public class Prod_CongeladosNitrogeno extends ProductosCongelados{
	private String metodo_congelacion_empl;
	private int tiempo_exp_nitrogeno;

	public Prod_CongeladosNitrogeno(String fecha_cad, int num_lote) {
	    super(fecha_cad, num_lote);
	}
	
	public Prod_CongeladosNitrogeno(String fecha_cad, int num_lote, String fecha_Env, String pais_Origen, 
			double temperatura, String metodo_congelacion_empl, int tiempo_exp_nitrogeno) {
		super(fecha_cad, num_lote, fecha_Env, pais_Origen, temperatura);
		this.metodo_congelacion_empl = metodo_congelacion_empl;
		this.tiempo_exp_nitrogeno = tiempo_exp_nitrogeno;
	}

	public String getMetodo_congelacion_empl() {
		return metodo_congelacion_empl;
	}

	public void setMetodo_congelacion_empl(String metodo_congelacion_empl) {
		this.metodo_congelacion_empl = metodo_congelacion_empl;
	}

	public int getTiempo_exp_nitrogeno() {
		return tiempo_exp_nitrogeno;
	}

	public void setTiempo_exp_nitrogeno(int tiempo_exp_nitrogeno) {
		this.tiempo_exp_nitrogeno = tiempo_exp_nitrogeno;
	}

	@Override
	public String toString() {
		return "Prod_CongeladosNitrogeno [metodo_congelacion_empl=" + metodo_congelacion_empl
				+ ", tiempo_exp_nitrogeno=" + tiempo_exp_nitrogeno + "]";
	}
	
	

}
