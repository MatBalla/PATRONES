package com;

import factory.FactoryGen;

import com.modelo.*;

import database.DatabaseConnection;
import database.Productos_db;

public class Test {

	public static void main(String[] args) {
		// 1. CREAR LA FÁBRICA E INICIALIZARLA (Indispensable)
	    FactoryGen factory = new FactoryGen();
	    factory.init("com.modelo"); 

	    // 2. CREAR TABLA
	    DatabaseConnection.crearTablaSiNoExiste();

	    // 3. USAR EL CRUD
	    Productos_db db = new Productos_db();
//	    
//	    // Prueba con un LOTE NUEVO cada vez para evitar el error de Primary Key
//	    ProductosFrescos manzana = new ProductosFrescos("2026-12-31", 120, "2026-04-01", "Ecuador");
//	    db.insertar(manzana);
//
//	    System.out.println("Productos en DB: " + db.listarTodos());
		
	 // 1. Probar eliminar el lote 505
	    //db.eliminar(505);
//
//	    // 2. Probar actualizar (primero creas el objeto con el mismo lote y datos nuevos)
//	    ProductosFrescos manzanaUpdate = new ProductosFrescos("2027-01-01", 600, "Chile", "2026-05-01");
//	    db.actualizar(manzanaUpdate);
	    
	    System.out.println("Productos en DB: " + db.listarTodos());
	    
	 // --- INSERTAR PRODUCTO POR AGUA ---
        Prod_CongeladosAgua pescado = new Prod_CongeladosAgua("2026-12-20", 701, "2026-04-10", "Noruega", -18.5, 35.0);
        db.insertar(pescado);

        // --- INSERTAR PRODUCTO por AIRE ---
        // Parámetros: fecha_cad, lote, fecha_env, pais, temp, %Nitrogeno, %Oxigeno, %CO2, %Vapor
        Prod_CongeladosAire carne = new Prod_CongeladosAire("2027-05-15", 802, "2026-04-12", "Argentina", -20.0, 78.0, 21.0, 0.03, 0.97);
        db.insertar(carne);

        // --- INSERTAR PRODUCTO POR NITRÓGENO ---
        // Parámetros: fecha_cad, lote, fecha_env, pais, temp, metodo, tiempo_exposicion
        Prod_CongeladosNitrogeno vegetal = new Prod_CongeladosNitrogeno("2026-10-30", 903, "2026-04-15", "México", -25.0, "Criogénico", 120);
        db.insertar(vegetal);
		

	}

}
