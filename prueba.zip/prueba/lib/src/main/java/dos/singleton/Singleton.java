package dos.singleton;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.DBConfig;

import dos.anotaciones.MiComponente;

@MiComponente(name = "servicioProductos", singleton = true)
public class Singleton {
	private static Singleton instancia = null;
	//private static Conection conection;
	private static DBConfig dbConfig;
	private static final Lock lock = new ReentrantLock();

	private Singleton() {
		try {
			var com = dbConfig.probarConexion();
			//dbConfig = (DBConfig) com;
			System.out.println("CONEXION EXITOSA!");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static Singleton getInstance() {
		if(instancia == null) {
			lock.lock();
			try {
				if(instancia == null) {
					instancia = new Singleton();
				}
				
			}finally {
				lock.unlock();
			}
			
		}else {
			System.out.println("Se devuelve la conexion existente");
		}
		return instancia;
	}
	
	
}
