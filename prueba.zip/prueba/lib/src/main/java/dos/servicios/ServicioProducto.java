package dos.servicios;



import java.util.List;

import com.DBConfig;
import com.Productos;

public interface ServicioProducto {
	void setDBConfig(DBConfig dbconfig);
	Productos buscarproducto(int id);
	List<Productos> listaProd();
void actualizar (Productos p);
void eliminar(int id);
void createProd(Productos p);
	
}
