package com;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DBConfig un = new DBConfig(); //Es la clase del crud
		 un.probarConexion();
		 
//		 un.insertar("Motecito con chicharron", 3);
		 
		 un.leer();

	}

}
