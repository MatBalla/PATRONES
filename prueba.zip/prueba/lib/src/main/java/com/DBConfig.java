package com;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.management.RuntimeErrorException;

//import com.zaxxer.hikari.HikariConfig;
//import com.zaxxer.hikari.HikariDataSource;

public class DBConfig {
	
//	private HikariConfig config = new HikariConfig();
//	private HikariDataSource dataSource;
	// 1. CREATE (Insertar)
	public void insertar(String nombre, int precio) {
		try {
	        Connection c = DriverManager.getConnection("jdbc:sqlite:Patrones.db");
	        String sql = "INSERT INTO productos (nombre, precio) VALUES (?, ?)";
	        PreparedStatement p = c.prepareStatement(sql);
	        p.setString(1, nombre);
	        p.setInt(2, precio);
	        p.executeUpdate();
	        System.out.println("GUARDADO");
	        c.close(); // Siempre cerramos al final
	    } catch (Exception e) {
	        System.out.println("No se pudo guardar: " + e.getMessage());
	    }
	}

    // 2. READ (Leer/Consultar)
	public void leer() {
		try {
	        Connection c = DriverManager.getConnection("jdbc:sqlite:Patrones.db"); ////atento de cambiarle en nombre a la base_de_datos.db
	        Statement s = c.createStatement();
	        ResultSet r = s.executeQuery("SELECT * FROM productos");
	        
	        while (r.next()) {
	            System.out.println(r.getInt("id") + " - " + r.getString("nombre"));
	        }
	        c.close();
	    } catch (Exception e) {
	        System.out.println("Error al mostrar: " + e.getMessage());
	    }
	}

    // 3. UPDATE (Actualizar)
	public void editar(int id, String nuevoNombre) {
	    String sql = "UPDATE productos SET nombre = ? WHERE id = ?";
	    try (Connection conn = DriverManager.getConnection("jdbc:sqlite:Patrones.db");
	         PreparedStatement p = conn.prepareStatement(sql)) {
	        p.setString(1, nuevoNombre);
	        p.setInt(2, id);
	        p.executeUpdate();
	        System.out.println("TAREA EDITADA");
	    } catch (Exception e) { System.out.println(e.getMessage()); }
	}

    // 4. DELETE (Eliminar)
	public void borrar(int id) {
		try {
	        Connection c = DriverManager.getConnection("jdbc:sqlite:Patrones.db");
	        PreparedStatement p = c.prepareStatement("DELETE FROM productos WHERE id = ?");
	        p.setInt(1, id);
	        p.executeUpdate();
	        System.out.println("Eliminado correctamente.");
	        c.close();
	    } catch (Exception e) {
	        System.out.println("Error: " + e.getMessage());
	    }
	}
    
    public boolean probarConexion() {
        // La URL debe coincidir exactamente con el nombre de tu archivo en Eclipse
        String url = "jdbc:sqlite:Patrones.db"; 
        
        // Intentamos conectar y ejecutar una consulta de integridad propia de SQLite
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {
            
            if (conn != null) {
                // "SELECT 1" es la forma más rápida de ver si la base de datos está viva
                stmt.executeQuery("SELECT 1");
                System.out.println("CONEXION EXITOSA");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error de conexión: " + e.getMessage());
        }
        return false;
    }
    
    
	
//	{
//		config.setJdbcUrl("jdbc:sqlite:productos.db");
//		config.setUsername("sa");
//		config.setPassword("");
//		config.setConnectionTimeout(1000);
//		dataSource = new HikariDataSource(config);
//	}
	
//	public Connection getConnection() {
//		try {
//			System.out.println("Conectando ...");
//			return dataSource.getConnection();
//		}catch (SQLException e) {
//			throw new RuntimeException(e);
//		}
//	}

}
