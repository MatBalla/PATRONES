package factory;

import ai.IAEstrategico;
import model.Personaje;
import platform.Plataforma;

public class BossFactory extends PersonajeFactory {

    @Override
    public Personaje crearPersonaje(String nombre, Plataforma plataforma) {
        Personaje b = new Personaje();
        b.setNombre(nombre);
        b.setTipo("Jefe Final");
        b.setNivel(50);
        b.setPuntosDeVida((int)(2000 * plataforma.getDificultad()));
        b.setAtaque((int)(300 * plataforma.getDificultad()));
        b.setDefensa((int)(200 * plataforma.getDificultad()));
        b.setComportamientoIA(new IAEstrategico());
        b.getInventario().agregarArma("Mazo Apocalíptico");
        b.getInventario().agregarArmadura("Armadura del Caos");
        b.getHabilidades().agregarHabilidadEspecial("Furia del Abismo");
        b.getHabilidades().agregarHabilidadEspecial("Llamada de Minions");
        b.getHabilidades().configurarAtaqueEspecial("Devastación Total");
        return b;
    }
}
