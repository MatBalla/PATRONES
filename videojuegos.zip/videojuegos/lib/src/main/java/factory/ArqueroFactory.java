package factory;

import ai.IADefensivo;
import model.Personaje;
import platform.Plataforma;

public class ArqueroFactory extends PersonajeFactory {

    @Override
    public Personaje crearPersonaje(String nombre, Plataforma plataforma) {
        Personaje a = new Personaje();
        a.setNombre(nombre);
        a.setTipo("Arquero");
        a.setNivel(1);
        a.setPuntosDeVida(100);
        a.setAtaque((int)(90 * plataforma.getDificultad()));
        a.setDefensa((int)(35 * plataforma.getDificultad()));
        a.setComportamientoIA(new IADefensivo());
        a.getInventario().agregarArma("Arco Largo");
        a.getInventario().agregarArma("Carcaj de Flechas");
        a.getHabilidades().agregarHabilidadEspecial("Flecha Envenenada");
        a.getHabilidades().configurarAtaqueEspecial("Lluvia de Flechas");
        return a;
    }
}
