package factory;

import model.Personaje;
import platform.Plataforma;

/**
 * PATRÓN: Factory Method
 * Define la interfaz para crear personajes, delegando
 * a las subclases qué tipo concreto instanciar.
 */
public abstract class PersonajeFactory {

    // Método de fábrica — cada subclase lo implementa
    public abstract Personaje crearPersonaje(String nombre, Plataforma plataforma);

    // Método plantilla: crea + configura plataforma
    public Personaje crearYConfigurar(String nombre, Plataforma plataforma) {
        Personaje p = crearPersonaje(nombre, plataforma);
        p.setPlataforma(plataforma);
        System.out.println("[Factory] Personaje creado: " + p.getNombre()
                + " [" + p.getTipo() + "] para " + plataforma.getNombre());
        return p;
    }
}
