package factory;

import ai.IAAgresivo;
import model.Personaje;
import platform.Plataforma;

public class GuerreroFactory extends PersonajeFactory {

    @Override
    public Personaje crearPersonaje(String nombre, Plataforma plataforma) {
        Personaje g = new Personaje();
        g.setNombre(nombre);
        g.setTipo("Guerrero");
        g.setNivel(1);
        g.setPuntosDeVida(150);
        g.setAtaque((int)(80 * plataforma.getDificultad()));
        g.setDefensa((int)(60 * plataforma.getDificultad()));
        g.setComportamientoIA(new IAAgresivo());
        g.getInventario().agregarArma("Espada de Hierro");
        g.getInventario().agregarArmadura("Armadura de Placas");
        g.getHabilidades().agregarHabilidadEspecial("Golpe Devastador");
        g.getHabilidades().configurarAtaqueEspecial("Torbellino");
        return g;
    }
}
