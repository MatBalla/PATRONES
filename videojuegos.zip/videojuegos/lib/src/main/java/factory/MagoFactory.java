package factory;

import ai.IAEstrategico;
import model.Personaje;
import platform.Plataforma;

public class MagoFactory extends PersonajeFactory {

    @Override
    public Personaje crearPersonaje(String nombre, Plataforma plataforma) {
        Personaje m = new Personaje();
        m.setNombre(nombre);
        m.setTipo("Mago");
        m.setNivel(1);
        m.setPuntosDeVida(80);
        m.setAtaque((int)(120 * plataforma.getDificultad()));
        m.setDefensa((int)(20 * plataforma.getDificultad()));
        m.setComportamientoIA(new IAEstrategico());
        m.getInventario().agregarArma("Bastón Arcano");
        m.getInventario().agregarPocion("Poción de Maná");
        m.getHabilidades().agregarHabilidadEspecial("Bola de Fuego");
        m.getHabilidades().agregarHabilidadEspecial("Escudo Arcano");
        m.getHabilidades().configurarAtaqueEspecial("Nova de Hielo");
        return m;
    }
}
