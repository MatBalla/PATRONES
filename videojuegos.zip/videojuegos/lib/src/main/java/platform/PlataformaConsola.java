package platform;

public class PlataformaConsola implements Plataforma {

    @Override public String getNombre()               { return "Consola"; }
    @Override public int    getCalidadGrafica()       { return 8; }
    @Override public double getDificultad()           { return 0.9; }
    @Override public int    getCantidadEnemigos()     { return 30; }
    @Override public int    getMemoriaMB()            { return 2048; }
    @Override public double getVelocidadAnimacion()   { return 0.95; }

    @Override
    public void mostrarConfig() {
        System.out.println("  [Consola] Gráficos: Alto | Memoria: 2GB | Enemigos: 30 | Animación: x0.95");
    }
}
