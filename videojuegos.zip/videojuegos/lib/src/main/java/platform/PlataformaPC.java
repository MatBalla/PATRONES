package platform;

public class PlataformaPC implements Plataforma {

    @Override public String getNombre()               { return "PC"; }
    @Override public int    getCalidadGrafica()       { return 10; }
    @Override public double getDificultad()           { return 1.0; }
    @Override public int    getCantidadEnemigos()     { return 50; }
    @Override public int    getMemoriaMB()            { return 8192; }
    @Override public double getVelocidadAnimacion()   { return 1.0; }

    @Override
    public void mostrarConfig() {
        System.out.println("  [PC] Gráficos: Ultra | Memoria: 8GB | Enemigos: 50 | Animación: x1.0");
    }
}
