package platform;

public interface Plataforma {
    String getNombre();
    int    getCalidadGrafica();     // 1-10
    double getDificultad();         // multiplicador
    int    getCantidadEnemigos();
    int    getMemoriaMB();
    double getVelocidadAnimacion(); // multiplicador
    void   mostrarConfig();
}
