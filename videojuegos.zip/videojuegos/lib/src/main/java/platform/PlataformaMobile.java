package platform;

public class PlataformaMobile implements Plataforma {

    @Override public String getNombre()               { return "Mobile"; }
    @Override public int    getCalidadGrafica()       { return 4; }
    @Override public double getDificultad()           { return 0.7; }
    @Override public int    getCantidadEnemigos()     { return 15; }
    @Override public int    getMemoriaMB()            { return 512; }
    @Override public double getVelocidadAnimacion()   { return 0.8; }

    @Override
    public void mostrarConfig() {
        System.out.println("  [Mobile] Gráficos: Bajo | Memoria: 512MB | Enemigos: 15 | Animación: x0.8");
    }
}
