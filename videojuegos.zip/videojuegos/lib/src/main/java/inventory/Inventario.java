package inventory;

import java.util.ArrayList;
import java.util.List;

public class Inventario implements Cloneable {

    private List<String> armas     = new ArrayList<>();
    private List<String> armaduras = new ArrayList<>();
    private List<String> pociones  = new ArrayList<>();

    public void agregarArma(String arma)         { armas.add(arma); }
    public void agregarArmadura(String armadura) { armaduras.add(armadura); }
    public void agregarPocion(String pocion)     { pociones.add(pocion); }

    public void listarInventario() {
        System.out.println("  ── Inventario ──────────────────");
        System.out.println("  Armas    : " + (armas.isEmpty()     ? "(vacío)" : String.join(", ", armas)));
        System.out.println("  Armaduras: " + (armaduras.isEmpty() ? "(vacío)" : String.join(", ", armaduras)));
        System.out.println("  Pociones : " + (pociones.isEmpty()  ? "(vacío)" : String.join(", ", pociones)));
    }

    @Override
    public Inventario clone() {
        try {
            Inventario clon = (Inventario) super.clone();
            clon.armas     = new ArrayList<>(this.armas);
            clon.armaduras = new ArrayList<>(this.armaduras);
            clon.pociones  = new ArrayList<>(this.pociones);
            return clon;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Error al clonar inventario", e);
        }
    }
}
