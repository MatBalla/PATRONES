package prototype;

import model.Personaje;
import java.util.HashMap;
import java.util.Map;

/**
 * PATRÓN: Prototype
 * Registro central de prototipos. Permite clonar personajes
 * registrados sin conocer su clase concreta.
 */
public class RegistroPrototipos {

    private static final Map<String, Personaje> registro = new HashMap<>();

    public static void registrar(String clave, Personaje personaje) {
        registro.put(clave, personaje);
        System.out.println("[Prototype] Registrado prototipo: " + clave);
    }

    public static Personaje clonar(String clave) {
        Personaje prototipo = registro.get(clave);
        if (prototipo == null) {
            throw new IllegalArgumentException("Prototipo no encontrado: " + clave);
        }
        Personaje clon = prototipo.clone();
        System.out.println("[Prototype] Clonado desde: " + clave);
        return clon;
    }

    public static void listarPrototipos() {
        System.out.println("  Prototipos registrados: " + registro.keySet());
    }
}
