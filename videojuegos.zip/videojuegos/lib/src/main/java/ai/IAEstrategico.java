package ai;

public class IAEstrategico implements ComportamientoIA {
    @Override public String getNombreComportamiento() { return "Estratégico"; }
    @Override public void ejecutar(String nombre) {
        System.out.println("  [IA-Estratégico] " + nombre + " evalúa el campo y ejecuta la mejor táctica.");
    }
}
