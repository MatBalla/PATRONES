package ai;

public class IAAgresivo implements ComportamientoIA {
    @Override public String getNombreComportamiento() { return "Agresivo"; }
    @Override public void ejecutar(String nombre) {
        System.out.println("  [IA-Agresivo] " + nombre + " ataca sin descanso al enemigo más cercano.");
    }
}
