package ai;

public class IAPasivo implements ComportamientoIA {
    @Override public String getNombreComportamiento() { return "Pasivo"; }
    @Override public void ejecutar(String nombre) {
        System.out.println("  [IA-Pasivo] " + nombre + " deambula y no inicia combate.");
    }
}
