package ai;

public class IADefensivo implements ComportamientoIA {
    @Override public String getNombreComportamiento() { return "Defensivo"; }
    @Override public void ejecutar(String nombre) {
        System.out.println("  [IA-Defensivo] " + nombre + " protege posición y contraataca solo si es atacado.");
    }
}
