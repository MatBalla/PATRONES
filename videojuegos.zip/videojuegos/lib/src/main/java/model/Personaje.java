package model;

import inventory.Inventario;
import skills.Habilidades;
import ai.ComportamientoIA;
import platform.Plataforma;
import java.util.ArrayList;
import java.util.List;

public class Personaje implements Cloneable {

    private String nombre;
    private int nivel;
    private int puntosDeVida;
    private int ataque;
    private int defensa;
    private String tipo;
    private Plataforma plataforma;
    private Inventario inventario;
    private Habilidades habilidades;
    private ComportamientoIA comportamientoIA;

    public Personaje() {
        this.inventario  = new Inventario();
        this.habilidades = new Habilidades();
    }

    // ── Prototype ──────────────────────────────────────────────────────────────
    @Override
    public Personaje clone() {
        try {
            Personaje clon = (Personaje) super.clone();
            clon.inventario  = this.inventario.clone();
            clon.habilidades = this.habilidades.clone();
            return clon;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Error al clonar personaje", e);
        }
    }

    // ── Getters y Setters ──────────────────────────────────────────────────────
    public String getNombre()                       { return nombre; }
    public void   setNombre(String nombre)          { this.nombre = nombre; }

    public int  getNivel()                          { return nivel; }
    public void setNivel(int nivel)                 { this.nivel = nivel; }

    public int  getPuntosDeVida()                   { return puntosDeVida; }
    public void setPuntosDeVida(int puntosDeVida)   { this.puntosDeVida = puntosDeVida; }

    public int  getAtaque()                         { return ataque; }
    public void setAtaque(int ataque)               { this.ataque = ataque; }

    public int  getDefensa()                        { return defensa; }
    public void setDefensa(int defensa)             { this.defensa = defensa; }

    public String getTipo()                         { return tipo; }
    public void   setTipo(String tipo)              { this.tipo = tipo; }

    public Plataforma getPlataforma()               { return plataforma; }
    public void setPlataforma(Plataforma p)         { this.plataforma = p; }

    public Inventario  getInventario()              { return inventario; }
    public Habilidades getHabilidades()             { return habilidades; }

    public ComportamientoIA getComportamientoIA()   { return comportamientoIA; }
    public void setComportamientoIA(ComportamientoIA ia) { this.comportamientoIA = ia; }

    // ── Mostrar ────────────────────────────────────────────────────────────────
    @Override
    public String toString() {
        return """
               ╔══════════════════════════════════════╗
                 PERSONAJE: %s [%s]
               ╠══════════════════════════════════════╣
                 Nivel   : %d
                 HP      : %d
                 Ataque  : %d
                 Defensa : %d
                 Plataforma: %s
                 IA      : %s
               ╚══════════════════════════════════════╝
               """.formatted(
                nombre, tipo, nivel, puntosDeVida, ataque, defensa,
                plataforma != null ? plataforma.getNombre() : "N/A",
                comportamientoIA != null ? comportamientoIA.getNombreComportamiento() : "N/A"
        );
    }
}
