package main;

import ai.*;
import builder.PersonajeBuilder;
import factory.*;
import model.Personaje;
import platform.*;
import prototype.RegistroPrototipos;

/**
 * Motor de Videojuegos Multiplataforma
 * Demuestra los tres patrones creacionales:
 *   - Factory Method
 *   - Builder
 *   - Prototype
 */
public class Main {

    public static void main(String[] args) {

        // ══════════════════════════════════════════════════════════════
        //  PLATAFORMAS
        // ══════════════════════════════════════════════════════════════
        titulo("CONFIGURACIÓN DE PLATAFORMAS");

        Plataforma pc      = new PlataformaPC();
        Plataforma mobile  = new PlataformaMobile();
        Plataforma consola = new PlataformaConsola();

        pc.mostrarConfig();
        mobile.mostrarConfig();
        consola.mostrarConfig();

        // ══════════════════════════════════════════════════════════════
        //  FACTORY METHOD — crear personajes por plataforma
        // ══════════════════════════════════════════════════════════════
        titulo("PATRÓN FACTORY METHOD");

        PersonajeFactory factGuerrero = new GuerreroFactory();
        PersonajeFactory factMago     = new MagoFactory();
        PersonajeFactory factArquero  = new ArqueroFactory();
        PersonajeFactory factEnemigo  = new EnemigоFactory();
        PersonajeFactory factBoss     = new BossFactory();

        Personaje guerreroPC    = factGuerrero.crearYConfigurar("Thorin",     pc);
        Personaje magoConsola   = factMago.crearYConfigurar("Gandalf",        consola);
        Personaje arqueroMobile = factArquero.crearYConfigurar("Legolas",     mobile);
        Personaje enemigoPC     = factEnemigo.crearYConfigurar("Orco Base",   pc);
        Personaje bossConsola   = factBoss.crearYConfigurar("Sauron",         consola);

        System.out.println(guerreroPC);
        System.out.println(magoConsola);
        System.out.println(arqueroMobile);

        // Mostrar inventario y habilidades del guerrero
        System.out.println("  === Detalle Thorin ===");
        guerreroPC.getInventario().listarInventario();
        guerreroPC.getHabilidades().mostrarHabilidades();
        guerreroPC.getComportamientoIA().ejecutar(guerreroPC.getNombre());

        System.out.println("\n  === Detalle Sauron (Boss) ===");
        System.out.println(bossConsola);
        bossConsola.getInventario().listarInventario();
        bossConsola.getHabilidades().mostrarHabilidades();
        bossConsola.getComportamientoIA().ejecutar(bossConsola.getNombre());

        // ══════════════════════════════════════════════════════════════
        //  BUILDER — construcción paso a paso
        // ══════════════════════════════════════════════════════════════
        titulo("PATRÓN BUILDER");

        Personaje personajeCustom = new PersonajeBuilder()
                .nombre("Xanathos")
                .tipo("Nigromante")
                .nivel(25)
                .puntosDeVida(180)
                .ataque(110)
                .defensa(50)
                .plataforma(pc)
                .comportamientoIA(new IAEstrategico())
                .arma("Báculo de Huesos")
                .arma("Daga Maldita")
                .armadura("Túnica del Vacío")
                .pocion("Elixir de Oscuridad")
                .habilidadEspecial("Invocar No-Muertos")
                .habilidadEspecial("Drenar Vida")
                .ataqueEspecial("Explosión de Almas")
                .build();

        System.out.println(personajeCustom);
        personajeCustom.getInventario().listarInventario();
        personajeCustom.getHabilidades().mostrarHabilidades();
        personajeCustom.getComportamientoIA().ejecutar(personajeCustom.getNombre());

        // ══════════════════════════════════════════════════════════════
        //  PROTOTYPE — clonar y generar variantes de enemigos
        // ══════════════════════════════════════════════════════════════
        titulo("PATRÓN PROTOTYPE — Clonación de Orcos");

        // Registrar el Orco Base como prototipo
        RegistroPrototipos.registrar("orco-base", enemigoPC);
        RegistroPrototipos.listarPrototipos();

        // Clonar → Orco Elite
        Personaje orcoElite = RegistroPrototipos.clonar("orco-base");
        orcoElite.setNombre("Orco Elite");
        orcoElite.setNivel(10);
        orcoElite.setPuntosDeVida(orcoElite.getPuntosDeVida() + 50);
        orcoElite.setAtaque(orcoElite.getAtaque() + 20);
        orcoElite.getInventario().agregarArma("Hacha de Guerra");
        orcoElite.getInventario().agregarArmadura("Cota de Malla");
        orcoElite.getHabilidades().agregarHabilidadEspecial("Grito de Batalla");

        // Clonar → Orco Mago
        Personaje orcoMago = RegistroPrototipos.clonar("orco-base");
        orcoMago.setNombre("Orco Mago");
        orcoMago.setNivel(8);
        orcoMago.setPuntosDeVida(orcoMago.getPuntosDeVida() - 10);
        orcoMago.setAtaque(orcoMago.getAtaque() + 40);
        orcoMago.setComportamientoIA(new IAEstrategico());
        orcoMago.getInventario().agregarArma("Cetro Shamanístico");
        orcoMago.getHabilidades().agregarHabilidadEspecial("Maldición Tribal");
        orcoMago.getHabilidades().configurarAtaqueEspecial("Tormenta Chamánica");

        // Clonar → Orco Berserker
        Personaje orcoBerserker = RegistroPrototipos.clonar("orco-base");
        orcoBerserker.setNombre("Orco Berserker");
        orcoBerserker.setNivel(12);
        orcoBerserker.setPuntosDeVida(orcoBerserker.getPuntosDeVida() + 80);
        orcoBerserker.setAtaque(orcoBerserker.getAtaque() + 60);
        orcoBerserker.setDefensa(Math.max(0, orcoBerserker.getDefensa() - 10));
        orcoBerserker.setComportamientoIA(new IAAgresivo());
        orcoBerserker.getInventario().agregarArma("Doble Hacha Salvaje");
        orcoBerserker.getHabilidades().agregarHabilidadEspecial("Frenesi");
        orcoBerserker.getHabilidades().configurarAtaqueEspecial("Embestida Brutal");

        // Mostrar las tres variantes
        System.out.println("\n  ── Original ──────────────────────────");
        System.out.println(enemigoPC);

        System.out.println("  ── Orco Elite ────────────────────────");
        System.out.println(orcoElite);
        orcoElite.getInventario().listarInventario();
        orcoElite.getHabilidades().mostrarHabilidades();

        System.out.println("  ── Orco Mago ─────────────────────────");
        System.out.println(orcoMago);
        orcoMago.getInventario().listarInventario();
        orcoMago.getHabilidades().mostrarHabilidades();
        orcoMago.getComportamientoIA().ejecutar(orcoMago.getNombre());

        System.out.println("  ── Orco Berserker ────────────────────");
        System.out.println(orcoBerserker);
        orcoBerserker.getInventario().listarInventario();
        orcoBerserker.getHabilidades().mostrarHabilidades();
        orcoBerserker.getComportamientoIA().ejecutar(orcoBerserker.getNombre());

        // ══════════════════════════════════════════════════════════════
        //  RESUMEN FINAL
        // ══════════════════════════════════════════════════════════════
        titulo("RESUMEN DEL SISTEMA");
        System.out.println("  Patrones aplicados:");
        System.out.println("    ✔ Factory Method  → GuerreroFactory, MagoFactory, ArqueroFactory, EnemigоFactory, BossFactory");
        System.out.println("    ✔ Builder         → PersonajeBuilder (fluent API)");
        System.out.println("    ✔ Prototype       → RegistroPrototipos + Personaje.clone()");
        System.out.println("  Plataformas soportadas: PC | Consola | Mobile");
        System.out.println("  Comportamientos IA: Agresivo | Defensivo | Estratégico | Pasivo");
    }

    // ── Utilidad de presentación ───────────────────────────────────────────────
    private static void titulo(String texto) {
        System.out.println("\n╔══════════════════════════════════════════════════╗");
        System.out.printf( "║  %-48s║%n", texto);
        System.out.println("╚══════════════════════════════════════════════════╝\n");
    }
}
