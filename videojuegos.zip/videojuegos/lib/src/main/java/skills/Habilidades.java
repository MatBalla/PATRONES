package skills;

import java.util.ArrayList;
import java.util.List;

public class Habilidades implements Cloneable {

    private List<String> habilidadesEspeciales = new ArrayList<>();
    private List<String> ataquesEspeciales     = new ArrayList<>();

    public void agregarHabilidadEspecial(String habilidad) {
        habilidadesEspeciales.add(habilidad);
    }

    public void configurarAtaqueEspecial(String ataque) {
        ataquesEspeciales.add(ataque);
    }

    public void mostrarHabilidades() {
        System.out.println("  ── Habilidades ─────────────────");
        System.out.println("  Especiales: " + (habilidadesEspeciales.isEmpty()
                ? "(ninguna)" : String.join(", ", habilidadesEspeciales)));
        System.out.println("  Ataques   : " + (ataquesEspeciales.isEmpty()
                ? "(ninguno)" : String.join(", ", ataquesEspeciales)));
    }

    @Override
    public Habilidades clone() {
        try {
            Habilidades clon = (Habilidades) super.clone();
            clon.habilidadesEspeciales = new ArrayList<>(this.habilidadesEspeciales);
            clon.ataquesEspeciales     = new ArrayList<>(this.ataquesEspeciales);
            return clon;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Error al clonar habilidades", e);
        }
    }
}
